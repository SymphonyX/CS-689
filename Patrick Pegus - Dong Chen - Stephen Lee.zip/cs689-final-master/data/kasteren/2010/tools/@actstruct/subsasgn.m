function a = subsasgn(a,index,val)

% ACTASTRUCT/ACTASTRUCT		A class for storing data from datasets in a
%                             standardized way
%
% Change History :
% Date           Time	Prog	Note
% 19-July-2006	 13:04  TvK     Created under MATLAB 7.1.0.246

% Tvk = Tim van Kasteren
% University of Amsterdam (UvA) - Intelligent Autonomous Systems (IAS) group
% e-mail : tlmkaste@science.uva.nl
% website: http://www.science.uva.nl/~tlmkaste/

error('Please use the constructor to assign values to a datastruct, or concatenate two datastructs using: as = [as1 ; as2];');