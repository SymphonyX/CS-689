function [ss2] = horzcat(ss, varargin)


error('Cannot concatenate tpattern horizontaly, try tp = [tp1 ; tp2] instead')

