load sensorStructHouseC.mat
load actStructHouseC.mat
load senseandactLabelsHouseC.mat

