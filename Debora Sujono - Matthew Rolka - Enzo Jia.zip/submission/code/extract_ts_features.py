import dtw
import glob
import re
import sys

import numpy as np
import pandas as pd

from sklearn import neighbors

ts_feats = {feat: [] for feat in ['Albumin',
    'ALP',
    'ALT',
    'AST',
    'Bilirubin',
    'BUN',
    'Cholesterol',
    'Creatinine',
    'DiasABP',
    'FiO2',
    'GCS',
    'Glucose',
    'HCO3',
    'HCT',
    'HR',
    'K',
    'Lactate',
    'Mg',
    'MAP',
    'MechVent',
    'Na',
    'NIDiasABP',
    'NIMAP',
    'NISysABP',
    'PaCO2',
    'PaO2',
    'pH',
    'Platelets',
    'RespRate',
    'SaO2',
    'SysABP',
    'Temp',
    'TroponinI',
    'TroponinT',
    'Urine',
    'WBC',
    'Weight']
}

data_dir = sys.argv[1]
label_file = sys.argv[2]

# Read features
id_to_idx = {}
id_list = []
for i, filename in enumerate(glob.iglob(data_dir + '/*.txt')):
    if i % 100 == 0: sys.stdout.write('\rReading record %d/%d' % (i, 4000))

    # Save record id index i
    match = re.search('\/(\d+)\.txt', filename)
    record_id = int(match.group(1))
    id_to_idx[record_id] = i
    id_list.append(record_id)

    seen_ts_feats = set()
    df = pd.read_csv(filename)
    grouped = df.groupby('Parameter')
    for feat, feat_df in grouped:
        if feat in ts_feats:
            seen_ts_feats.add(feat)
            ts = np.array(feat_df['Value'], dtype='float64')
            ts[np.where(ts < 0)] = np.mean(ts)
            ts_feats[feat].append(ts)

    unseen_feats = set(ts_feats) - seen_ts_feats
    for feat in unseen_feats:
        ts_feats[feat].append(None)

    assert [len(X) == i + 1 for X in ts_feats.values()]
            
    """
    f = open(filename, 'r')
    ts = []
    for line in f:
        t, feat, val = line.split(',')
        if feat == 'HR':
            ts.append(float(val))

    if len(ts) == 0: missing_indices.append(i)
    f.close()
    X.append(np.array(ts))
    """

n_samples = i + 1
sys.stdout.write('\rReading record %d/%d' % (n_samples, 4000))
print

# Write list of record ids
f = open('ts_out/records_ids.txt', 'w')
for record_id in id_list:
    f.write(str(record_id) + '\n')

# Read labels
print 'Reading labels'
f = open(label_file, 'r')
y = np.zeros(n_samples)
f.next()
for line in f:
    record_id, _, _, _, _, label = line.split(',')
    y[id_to_idx[int(record_id)]] = label

# Split train/test labels
split = int(n_samples * 0.8)
y_train = y[:split]
y_test = y[split:]

assert [len(X) == n_samples for X in ts_feats.values()]
assert y.shape == (n_samples, )

for i, (feat, X) in enumerate(ts_feats.iteritems()):
    print 'Feature %d/%d %s' % (i + 1, len(ts_feats), feat)

    # Impute missing sequences using mean
    print 'Imputing'
    #mean = np.mean([v for ts in X if ts is not None for v in ts])
    mean = np.mean([ts[0] for ts in X if ts is not None])
    for j, ts in enumerate(X):
        if ts is None:
            X[j] = [mean]
    assert all([ts is not None for ts in X])
    
    # Split train/test features
    ts_train = X[:split]
    ts_test = X[split:]
    
    # Compute distance matrices
    print 'Computing training distance matrix'
    X_train = dtw.dist_matrix(ts_train, ts_train)
    print 'Computing test distance matrix'
    X_test = dtw.dist_matrix(ts_test, ts_train)
    assert X_train.shape == (split, split)
    assert X_test.shape == (n_samples - split, split)
    
    print 'Training KNN regressor'
    filename = 'ts_out/%s.txt' % feat
    est = neighbors.KNeighborsClassifier(weights='distance', n_neighbors=5, algorithm='brute')
    est.metric = 'precomputed'
    dtw.estimate(X_train, y_train, X_test, y_test, filename, est)
        