import dtw
import eval_util
import glob
import re
import sys

import numpy as np
import pandas as pd

#from sklearn import neighbors
from sklearn.preprocessing import Imputer, StandardScaler
from sklearn.metrics import roc_auc_score, roc_curve, confusion_matrix
from sklearn.svm import SVC
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier

gen_feats = {
    'Age',
    'Gender', #(0: female, or 1: male)
    'Height'
}

cat_feats = {
    'ICUType' #(1: Coronary Care Unit, 2: Cardiac Surgery Recovery Unit, 3: Medical ICU, or 4: Surgical ICU)
}

ts_feats = {'Albumin',
    'ALP',
    'ALT',
    'AST',
    'Bilirubin',
    'BUN',
    'Cholesterol',
    'Creatinine',
    'DiasABP',
    'FiO2',
    'GCS',
    'Glucose',
    'HCO3',
    'HCT',
    'HR',
    'K',
    'Lactate',
    'Mg',
    'MAP',
    'MechVent',
    'Na',
    'NIDiasABP',
    'NIMAP',
    'NISysABP',
    'PaCO2',
    'PaO2',
    'pH',
    'Platelets',
    'RespRate',
    'SaO2',
    'SysABP',
    'Temp',
    'TroponinI',
    'TroponinT',
    'Urine',
    'WBC',
    'Weight'
}

gen_feat_idx = {f: i for i, f in enumerate(gen_feats)}

data_dir = sys.argv[1]
ts_dir = sys.argv[2]
label_file = sys.argv[3]
n_static_feats = len(gen_feats) + len(cat_feats)

# Read record id index
f = open('ts_out/records_ids.txt', 'r')
rec_id_idx = {}
for i, line in enumerate(f):
    rec_id = int(line.strip())
    rec_id_idx[rec_id] = i
n_samples = i + 1

# Read ts features
print 'Reading ts data'
X_ts = np.full((n_samples, len(ts_feats)), np.nan)
for i, feat in enumerate(ts_feats):
    filename = 'ts_out/%s.txt' % feat
    X_ts[:, i] = np.genfromtxt(filename)[:, 1]
assert not np.any(np.isnan(X_ts))

# Read static features
print 'Reading static data'
X_static_ord = np.full((n_samples, len(gen_feats)), np.nan)
X_static_cat = np.zeros((n_samples, 4))
for filename in glob.iglob(data_dir + '/*.txt'):
    #print filename
    f = open(filename, 'r')
    f.next() # skip header

    # Get index of record id
    _, _, rec_id = f.next().split(',')
    i = rec_id_idx[int(rec_id)]

    n_seen_feats = 0
    for line in f:
        _, feat, val = line.split(',')

        # Read ordinal feature
        if feat in gen_feats:
            val = float(val)
            if val >= 0:
                X_static_ord[i, gen_feat_idx[feat]] = val
            n_seen_feats += 1
    
        # Read and one-hot-encode categorical feature (ICUType)
        elif feat in cat_feats:
            j = int(val) - 1
            X_static_cat[i, j] = 1
            n_seen_feats += 1

        if n_seen_feats == n_static_feats: break

X = np.hstack((X_static_ord, X_static_cat, X_ts))
assert X.shape == (n_samples, len(gen_feats) + 4 + len(ts_feats))

# Read labels
print 'Reading labels'
f = open(label_file, 'r')
y = np.zeros(n_samples)
f.next()
for line in f:
    rec_id, _, _, _, _, label = line.split(',')
    y[rec_id_idx[int(rec_id)]] = label

# Split train/test set
split = int(len(X) * 0.8)
print split
X_train = X[:split]
y_train = y[:split]
X_test = X[split:]
y_test = y[split:]

# Impute np.nan values in X
imputer = Imputer().fit(X_train)
X_train = imputer.transform(X_train)
X_test = imputer.transform(X_test)
assert not np.any(np.isnan(X_train))
assert not np.any(np.isnan(X_test))

# Scale features
print 'Scaling features'
scaler = StandardScaler().fit(X_train)
X_train = scaler.transform(X_train)
X_test = scaler.transform(X_test)

# Classify
#clf = LogisticRegression(class_weight='balanced', C=2)
clf = SVC(class_weight='balanced', probability=True, C=0.5)
#clf = RandomForestClassifier(n_estimators=1000, class_weight='balanced_subsample')
clf.fit(X_train, y_train)
y_pred = clf.predict(X_test)
y_probs = clf.predict_proba(X_test)[:, 1]
m = confusion_matrix(y_test, y_pred)
print '# positive predictions:', sum(y_pred)
print 'Model sensitivity:', eval_util.sensitivity(m)
print 'Model specificity:', eval_util.specificity(m)
print 'Model accuracy:', np.sum(y_test == y_pred), len(y_test), float(np.sum(y_test == y_pred)) / len(y_test)
print 'Model AUC:', roc_auc_score(y_test, y_probs, average=None)

# Best p
p = eval_util.best_threshold(y_test, y_probs)
new_pred = y_probs > p
m = confusion_matrix(y_test, new_pred)
print '# positive predictions:', sum(new_pred)
print 'Best-p model sensitivity:', eval_util.sensitivity(m)
print 'Model specificity:', eval_util.specificity(m)
print 'Model accuracy:', np.sum(y_test == new_pred), len(y_test), float(np.sum(y_test == new_pred)) / len(y_test)
print 'Model AUC:', roc_auc_score(y_test, y_probs, average=None)

# Random
y_rand = np.random.binomial(1, np.mean(y_train), len(X_test))
print '# positive predictions:', sum(y_rand)
print 'Random accuracy:', np.sum(y_test == y_rand), len(y_test), float(np.sum(y_rand == y_pred)) / len(y_test)
print 'Random AUC:', roc_auc_score(y_test, y_rand, average=None)
