import sys
import util

import numpy as np

from scipy.stats import f_oneway, chi2_contingency
from sklearn.preprocessing import OneHotEncoder

data_dir = sys.argv[1]
label_file = sys.argv[2]
out_file = sys.argv[3]
cutoff = float(sys.argv[4])
if len(sys.argv) > 5:
    out_best = sys.argv[5]
else:
    out_best = None #'best_features.txt'

def first(l):
    return l[0]

def last(l):
    return l[-1]

def anova(X, y):
    _, ncol = X.shape
    best_indices = []
    for j in range(ncol):
        col = X[:, j]
        pos = col[np.where(y == 1)]
        neg = col[np.where(y == 0)]
        
        # Perform ANOVA test
        stat, p = f_oneway(pos, neg)
    
        if p < cutoff:
            best_indices.append(j)
    
    return np.array(best_indices, dtype=int)

def chi2(X, y):
    _, ncol = X.shape
    best_indices = []
    for j in range(ncol):
        # For each feature, create a contingency table
        col = X[:, j]
        tbl = np.zeros((max(col) + 1, 2))
        for val, label in zip(col, y):
            tbl[val, label] += 1

        # Perform chi-squared test
        stat, p, _, _ = chi2_contingency(tbl)
        if p < cutoff:
            best_indices.append(j)

    return np.array(best_indices, dtype=int)

def best_features_to_str(best_indices, feats):
    s = []
    for idx in best_indices:
        s.append(feats[idx])

    return '\n'.join(s) + '\n'

# Define features
gen_cont_feats = ['Age', 'Height']

gen_disc_feats = ['ICUType', #(1: Coronary Care Unit, 2: Cardiac Surgery Recovery Unit, 3: Medical ICU, or 4: Surgical ICU)
    'Gender'] #(0: female, or 1: male)

ts_cont_feats = ['Albumin',
    'ALP',
    'ALT',
    'AST',
    'Bilirubin',
    'BUN',
    'Cholesterol',
    'Creatinine',
    'DiasABP',
    'FiO2',
    'GCS',
    'Glucose',
    'HCO3',
    'HCT',
    'HR',
    'K',
    'Lactate',
    'Mg',
    'MAP',
    'Na',
    'NIDiasABP',
    'NIMAP',
    'NISysABP',
    'PaCO2',
    'PaO2',
    'pH',
    'Platelets',
    'RespRate',
    'SaO2',
    'SysABP',
    'Temp',
    'TroponinI',
    'TroponinT',
    'Urine',
    'WBC',
    'Weight']

ts_disc_feats = ['MechVent']

gen_cont_feat_idx = {f: i for i, f in enumerate(gen_cont_feats)}
gen_disc_feat_idx = {f: i for i, f in enumerate(gen_disc_feats)}
ts_cont_feat_idx = {f: i for i, f in enumerate(ts_cont_feats)}
ts_disc_feat_idx = {f: i for i, f in enumerate(ts_disc_feats)}

# Read record ids and labels
rec_ids = []
y = []

f = open(label_file, 'r')
f.next()
for line in f:
    rec_id, _, _, _, _, label = line.split(',')
    rec_ids.append(rec_id)
    y.append(label)
y = np.array(y, dtype=int)

# Read continuous features
print 'Reading continuous features'
X_gen_cont, X_gen_cont_raw = util.create_gen_mat(data_dir, rec_ids, gen_cont_feat_idx, float)
X_first_cont, X_first_cont_raw = util.create_summary_stat_mat(data_dir, rec_ids, ts_cont_feat_idx, first, float)
X_min_cont, X_min_cont_raw = util.create_summary_stat_mat(data_dir, rec_ids, ts_cont_feat_idx, min, float)
X_median_cont, X_median_cont_raw = util.create_summary_stat_mat(data_dir, rec_ids, ts_cont_feat_idx, np.median, float)
X_max_cont, X_max_cont_raw = util.create_summary_stat_mat(data_dir, rec_ids, ts_cont_feat_idx, max, float)
X_last_cont, X_last_cont_raw = util.create_summary_stat_mat(data_dir, rec_ids, ts_cont_feat_idx, last, float)

# Read discrete features
print 'Reading discrete features'
X_gen_disc, X_gen_disc_raw = util.create_gen_mat(data_dir, rec_ids, gen_disc_feat_idx, int)
X_first_disc, X_first_disc_raw = util.create_summary_stat_mat(data_dir, rec_ids, ts_disc_feat_idx, first, int)
X_min_disc, X_min_disc_raw = util.create_summary_stat_mat(data_dir, rec_ids, ts_disc_feat_idx, min, int)
X_median_disc, X_median_disc_raw = util.create_summary_stat_mat(data_dir, rec_ids, ts_disc_feat_idx, np.median, int)
X_max_disc, X_max_disc_raw = util.create_summary_stat_mat(data_dir, rec_ids, ts_disc_feat_idx, max, int)
X_last_disc, X_last_disc_raw = util.create_summary_stat_mat(data_dir, rec_ids, ts_disc_feat_idx, last, int)

# ANOVA for continuous features
print 'Running ANOVA for continuous features'
best_gen_cont = anova(X_gen_cont, y)
best_first_cont = anova(X_first_cont, y)
best_min_cont = anova(X_min_cont, y)
best_median_cont = anova(X_median_cont, y)
best_max_cont = anova(X_max_cont, y)
best_last_cont = anova(X_last_cont, y)

# Chi-squared for discrete features
print 'Running chi-squared for discrete features'
best_gen_disc = chi2(X_gen_disc, y)
best_first_disc = chi2(X_first_disc, y)
best_min_disc = chi2(X_min_disc, y)
best_median_disc = chi2(X_median_disc, y)
best_max_disc = chi2(X_max_disc, y)
best_last_disc = chi2(X_last_disc, y)

# Write best features
if out_best:
    best_feats_out = open(out_best, 'w')
    
    # Write best static features
    best_feats_out.write('Best static features:\n')
    best_feats_out.write(best_features_to_str(best_gen_cont, gen_cont_feats))
    best_feats_out.write(best_features_to_str(best_gen_disc, gen_disc_feats))
    best_feats_out.write('\n')
    
    # Write best first TS features
    best_feats_out.write('Best first TS features:\n')
    best_feats_out.write(best_features_to_str(best_first_cont, ts_cont_feats))
    best_feats_out.write(best_features_to_str(best_first_disc, ts_disc_feats))
    best_feats_out.write('\n')

    # Write best min TS features
    best_feats_out.write('Best min TS features:\n')
    best_feats_out.write(best_features_to_str(best_min_cont, ts_cont_feats))
    best_feats_out.write(best_features_to_str(best_min_disc, ts_disc_feats))
    best_feats_out.write('\n')
    
    # Write best median TS features
    best_feats_out.write('Best median TS features:\n')
    best_feats_out.write(best_features_to_str(best_median_cont, ts_cont_feats))
    best_feats_out.write(best_features_to_str(best_median_disc, ts_disc_feats))
    best_feats_out.write('\n')

    # Write best max TS features
    best_feats_out.write('Best max TS features:\n')
    best_feats_out.write(best_features_to_str(best_max_cont, ts_cont_feats))
    best_feats_out.write(best_features_to_str(best_max_disc, ts_disc_feats))
    best_feats_out.write('\n')
    
    # Write best last TS features
    best_feats_out.write('Best last TS features:\n')
    best_feats_out.write(best_features_to_str(best_last_cont, ts_cont_feats))
    best_feats_out.write(best_features_to_str(best_last_disc, ts_disc_feats))
    best_feats_out.write('\n')

# Output raw X, y
print 'Saving output'
"""
data = np.hstack((X_gen_disc_raw[:, best_gen_disc], X_first_disc_raw[:, best_first_disc],
                  X_min_disc_raw[:, best_min_disc], X_max_disc_raw[:, best_max_disc],
                  X_median_disc_raw[:, best_median_disc], X_last_disc_raw[:, best_last_disc],
                  X_gen_cont_raw[:, best_gen_cont], X_first_cont_raw[:, best_first_cont],
                  X_min_cont_raw[:, best_min_cont],X_max_cont_raw[:, best_max_cont],
                  X_median_cont_raw[:, best_median_cont], X_last_cont_raw[:, best_last_cont],
                  y[:, np.newaxis]))
"""
data = np.hstack((X_gen_disc_raw[:, best_gen_disc], X_first_disc_raw[:, best_first_disc],
                  X_median_disc_raw[:, best_median_disc], X_last_disc_raw[:, best_last_disc],
                  X_gen_cont_raw[:, best_gen_cont], X_first_cont_raw[:, best_first_cont],
                  X_median_cont_raw[:, best_median_cont], X_last_cont_raw[:, best_last_cont],
                  y[:, np.newaxis]))
print data.shape
np.savetxt(out_file, data)

# Print stats
nbest_disc = len(best_gen_disc) + len(best_first_disc) + len(best_median_disc) + len(best_last_disc) + len(best_min_disc) + len(best_max_disc)
nbest_cont = len(best_gen_cont) + len(best_first_cont) + len(best_median_cont) + len(best_last_cont) + len(best_min_cont) + len(best_max_cont)
cat_indices = [str(i) for i in range(nbest_disc)]
print 'Total # features:', nbest_disc + nbest_cont
print 'Categorical indices:', cat_indices
