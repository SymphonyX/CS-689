import glob
import re
import sys

import numpy as np
import pandas as pd

from sklearn import neighbors

data_dir = 'set-a' #sys.argv[1]
ts_dir = 'ts_out_interp' # sys.argv[2]
train_file = 'train_ids.txt' #sys.argv[3]
test_file = 'test_ids.txt' #ys.argv[4]
out_dir = 'hmm_features' #sys.argv[5]

gen_feats = {feat: i for i, feat in enumerate(['Age',
    'Gender', #(0: female, or 1: male)
    'Height'])  
}

cat_feats = {
    'ICUType' #(1: Coronary Care Unit, 2: Cardiac Surgery Recovery Unit, 3: Medical ICU, or 4: Surgical ICU)
}

n_static_feats = len(gen_feats) + len(cat_feats)

def read_X_ts(rec_ids):
    X = []
    for i, rec_id in enumerate(rec_ids):
        #if i % 100 == 0: sys.stdout.write('\rReading record %d/%d' % (i, 4000))
        X_i = np.genfromtxt('%s/%s.txt' % (ts_dir, rec_id))
        X.append(X_i)

    return np.array(X)

def read_X_static(rec_ids):
    X_static = []
    for rec_id in rec_ids:
        filename = '%s/%s.txt' % (data_dir, rec_id)
        f = open(filename, 'r')
        f.next() # skip header
    
        X_gen = np.full((24, len(gen_feats)), np.nan)
        X_cat = np.zeros((24, len(cat_feats) * 4))
    
        n_seen_feats = 0
        for line in f:
            t, feat, val = line.split(',')
    
            # Read static feature
            if feat in gen_feats:
                val = float(val)
                if val >= 0: X_gen[:, gen_feats[feat]] = val
                n_seen_feats += 1
        
            # Read and one-hot-encode ICUType feature
            elif feat in cat_feats:
                j = int(val) - 1
                X_cat[:, j] = 1
                n_seen_feats += 1
    
            if n_seen_feats == n_static_feats: break

        X_i = np.hstack((X_gen, X_cat))
        X_static.append(X_i)

    return np.array(X_static)

# Get train/test record ids
f = open(train_file, 'r')
train_ids = [int(rec_id) for rec_id in f]
f = open(test_file, 'r')
test_ids = [int(rec_id) for rec_id in f]
f.close()

# Read TS features
print 'Reading TS features'
X_ts_train = read_X_ts(train_ids)
X_ts_test = read_X_ts(test_ids)
print X_ts_train.shape
print X_ts_test.shape

# Read static features
print 'Reading static features'
X_static_train = read_X_static(train_ids)
X_static_test = read_X_static(test_ids)
print X_static_train.shape
print X_static_test.shape

# Combine TS and static features into X
X_train = np.dstack((X_ts_train, X_static_train))
X_test = np.dstack((X_ts_test, X_static_test))
print X_train.shape
print X_test.shape

# Impute missing values
print 'Imputing missing values'
means = np.nanmean(X_train, axis=0)
print means.shape

new_X_train = []
for X_i in X_train:
    X_i[np.where(np.isnan(X_i))] = means[np.where(np.isnan(X_i))]
    new_X_train.append(X_i)

new_X_test = []
for X_i in X_test:
    X_i[np.where(np.isnan(X_i))] = means[np.where(np.isnan(X_i))]
    new_X_test.append(X_i)

X_train = np.array(new_X_train)
X_test = np.array(new_X_test)

"""
train_nans = [(i, j, k) for i, j, k in zip(*np.where(np.isnan(X_train)))]
test_nans = [(i, j, k) for i, j, k in zip(*np.where(np.isnan(X_test)))]
#print train_nans, test_nans
means[[(j, k) for i, j, k in train_nans][:2]]
print np.all(np.array([j for i, j, k in train_nans]) < 24)
X_train[train_nans] = means[[(j, k) for i, j, k in train_nans]]
X_test[test_nans] = means[[(j, k) for i, j, k in test_nans]]
"""

assert not np.any(np.isnan(X_train))
assert not np.any(np.isnan(X_test))

# Write time x feature matrix for each patient record
print 'Writing features'
for rec_id, X in zip(train_ids + test_ids, np.vstack((X_train, X_test))):
    out = '%s/%s.txt' % (out_dir, rec_id)
    np.savetxt(out, X)
