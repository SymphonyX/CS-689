setwd('~/Courseworks/CMPSCI689/Final_Project/code/')

library(ROCR)
library(survival)
library(randomForestSRC)

name.file <- list.files(path = '../set-a/')
name.file <- paste('../set-a/', name.file, sep = '')

################################################# READ FILES #################################################

ptm <- proc.time()
content <- as.matrix(t(do.call(cbind, lapply(name.file, read.uneven.table))))
proc.time() - ptm

outcome <- read.table('../data/Outcomes-a.txt', sep = ',', header = T)

################################################# EXTRACT DATA #################################################

ptm <- proc.time()
mat.info.patient <- data.frame(t(apply(content, 1, info.extractor)))
proc.time() - ptm

################################################# CLEAN DATA #################################################

mat.info.patient[is.na(mat.info.patient)] <- -1
num.na <- colSums(mat.info.patient == -1, 1)
mat.info.patient.test <- mat.info.patient[, num.na < 1000]
dim(mat.info.patient.test)

mat.info.patient.dead <- mat.info.patient.test[outcome[['Survival']] > -1, ]
outcome.dead <- outcome[outcome[['Survival']] > -1, ]


################################################# MODELS #################################################

data.all <- cbind(mat.info.patient.test, times = outcome[['Survival']])
data.all <- cbind(data.all, status = outcome[['Survival']] > -1)
data.all <- cbind(data.all, in.hosp.death = outcome[['In.hospital_death']])

data.splitted <- data.splitter(data.all, 0.7)
data.test <- data.splitted[[1]]
data.train <- data.splitted[[2]]

cox.fitted <- coxph(Surv(times, status) ~ ., data.train)
# p <- predict(cox.fitted, data.test, type = 'risk')
p <- predict(cox.fitted, data.test, type = 'risk')
p <- p/max(p)
pred <- prediction(p, data.test[['in.hosp.death']], label.ordering = c(0,1 ))
plot(performance(pred, 'tpr', 'fpr'), lwd=2, xlim=c(0,1), ylim=c(0,1))
performance(pred, 'auc')@y.values[[1]]

output <- survfit(cox.fitted, data.test)
p <- output[['median']]/max(output[['median']])




data.all <- cbind(mat.info.patient.dead, times = outcome.dead[['Survival']])
data.all <- cbind(data.all, status = rep(1, dim(data.all)[1]))
data.all <- cbind(data.all, in.hosp.death = outcome.dead[['In.hospital_death']])

data.splitted <- data.splitter(data.all, 0.7)
data.test <- data.splitted[[1]]
data.train <- data.splitted[[2]]

cox.fitted <- coxph(Surv(times, status) ~ ., data.train)
# p <- predict(cox.fitted, data.test, type = 'risk')
p <- predict(cox.fitted, data.test, type = 'risk')
pred <- prediction(p, data.test[['in.hosp.death']], label.ordering = c(0,1 ))
plot(performance(pred, 'tpr', 'fpr'), lwd=2, xlim=c(0,1), ylim=c(0,1))

rfsrc.fitted <- rfsrc(Surv(times, status) ~ ., data.train, ntree = 2)
p <- predict(rfsrc.fitted, data.test)
pred <- prediction(p$predicted, data.test[['in.hosp.death']], label.ordering = c(0,1 ))
plot(performance(pred, 'tpr', 'fpr'), lwd=2, xlim=c(0,1), ylim=c(0,1))

# predict(cox.fitted, data.all[1:10,])
# predict(cox.fitted, data.all[1:10,], type = 'lp')
# predict(cox.fitted, data.all[1:10,], type = 'expected')
predict(cox.fitted, data.all[1:10,], type = 'risk')

################################################# UTILS #################################################

read.uneven.table <- function(str.file.name)
{
  table.this <- read.table(str.file.name)
  len.tail <- 1600 - dim(table.this)[1]
  tail.this <- data.frame(rep('15:15,Placebo,20', len.tail))
  # names(table.this) <- c('V1')
  names(tail.this) <- c('V1')
  return(rbind(table.this, tail.this))
}

info.extractor <- function(input_str)
{
  m_time <- gregexpr("^([0-9:]+)(?=,)", input_str, perl=TRUE)  
  m_parameter <- gregexpr("(?<=,)([A-Za-z0-9_\\-[:space:]]+)(?=,)", input_str, perl=TRUE)
  m_value <- gregexpr("(?<=,)([.A-Za-z0-9_\\-[:space:]]+)$", input_str, perl = T)
  str.time <- as.character( do.call(rbind, lapply(regmatches(input_str, m_time), `[`, c(1L))) )
  str.parameter <- as.character( do.call(rbind, lapply(regmatches(input_str, m_parameter), `[`, c(1L))) )
  str.value <- as.character( do.call(rbind, lapply(regmatches(input_str, m_value), `[`, c(1L))) )
  
  features <- c("RecordID", "Age", "Gender", "Height", "ICUType", "Weight", "GCS", "HR", "NIDiasABP", "NIMAP", "NISysABP", "Temp", "Urine",     
                "Albumin", "ALP", "ALT", "AST", "Bilirubin", "BUN", "Creatinine", "Glucose", "HCO3", "HCT", "Mg", "Platelets", "K",         
                "Na", "WBC", "Lactate", "FiO2", "MechVent", "pH", "PaCO2", "PaO2", "SaO2", "DiasABP", "MAP", "SysABP")
  patient.this <- data.frame(str.time, str.parameter, as.numeric(str.value))

  features.t0 <- paste(features, '.t0', sep = '')
  features.t48 <- paste(features, '.t48', sep = '')
  
  features.all <- c(features.t0, features.t48)
  
  mat.this <- rep(-1, length(features.all))
  names(mat.this) <- features.all
  
  for (i in 1:length(features))
  {
    values <- patient.this[patient.this[['str.parameter']] == features[i], ]
    if (dim(values)[1] > 0)
      mat.this[i] <- values[1, 3]
    if (dim(values)[1] > 1)
      mat.this[i + length(features)] <- values[dim(values)[1], 3]
  }
  return(mat.this)
}

data.splitter <- function(df.input, training.ratio){
  index.shuffled <- sample(1:dim(df.input)[1], dim(df.input)[1])
  df.testing <- df.input[index.shuffled[1:floor((1-training.ratio) * dim(df.input)[1])],]
  df.training <- df.input[index.shuffled[(floor((1-training.ratio) * dim(df.input)[1]) + 1):dim(df.input)[1]],]
  return(list(df.testing, df.training))
}