import glob
import re
import sys

import numpy as np
import pandas as pd

from sklearn import neighbors
from sklearn.utils import shuffle

label_file = sys.argv[1]
train_file = sys.argv[2]
test_file = sys.argv[3]

# Read record ids and labels
rec_ids = []
y = []

f = open(label_file, 'r')
f.next()
for line in f:
    rec_id, _, _, _, _, label = line.split(',')
    rec_ids.append(rec_id)
    y.append(label)

rec_ids = np.array(rec_ids, dtype=int)
y = np.array(y, dtype=int)
rec_ids, y = shuffle(rec_ids, y)

n_samples = len(y)

# Create train/test split
split = int(n_samples * 0.8)
train_ids = rec_ids[:split]
y_train = y[:split]
test_ids = rec_ids[split:]
y_test = y[split:]

# Group by label
train_ids1 = train_ids[np.where(y_train == 1)]
train_ids0 = train_ids[np.where(y_train == 0)]
test_ids1 = test_ids[np.where(y_test == 1)]
test_ids0 = test_ids[np.where(y_test == 0)]

out_train1 = '%s1.txt' % train_file
out_train0 = '%s0.txt' % train_file
out_test1 = '%s1.txt' % test_file
out_test0 = '%s0.txt' % test_file
np.savetxt(out_train1, train_ids1, fmt='%d')
np.savetxt(out_train0, train_ids0, fmt='%d')
np.savetxt(out_test1, test_ids1, fmt='%d')
np.savetxt(out_test0, test_ids0, fmt='%d')
