library(ggplot2)
library(reshape)

# Curves comparing different hyperparameters
title <- 'Performance vs regularization in logistic regression'
filename <- 'res_rfent_05'
df <- read.table(paste0(filename, '.txt'))[, -1]
df$c <- factor(c(0.1, 0.5, 1, 2, 5, 10))
colnames(df) <- c('auc', 'sensitivity', 'specificity', 'c')

melted_df <- melt(df, id='c')
colnames(melted_df) <- c('c', 'metric', 'score')

plot <- melted_df %>% ggplot(aes(x = c, y = score, group=metric, color=metric)) +
        geom_point() + geom_line() + ggtitle(title) + xlab('number of trees')
ggsave(filename = paste0('plots/', filename, '.jpg'))

# Plot comparing different classifiers
title <- 'Performance of classifiers'
filename <- 'res_tbl'
df <- read.csv(paste0(filename, '.csv'))[-1, ]
df$classifier <- factor(df$classifier,
                        levels=c('random', 'gaussian naive bayes', 'logistic regression',
                                 'svm', 'random forests', 'gradient boosted trees'))
melted_df <- melt(df, id='classifier')
colnames(melted_df) <- c('classifier', 'metric', 'score')
plot <- melted_df %>% ggplot(aes(x = classifier, y = score, fill=metric)) +
        geom_bar(stat='identity', position='dodge') + ggtitle(title) +
        ylab('score (%)')
ggsave(filename = paste0('plots/', filename, '.jpg'))
