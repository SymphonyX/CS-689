import numpy as np
import mlpy
"""
from rpy2.robjects import numpy2ri, r
from rpy2.robjects.packages import importr
"""

# Setup R namespaces
"""
importr('dtw')
numpy2ri.activate()
"""

# Compute a distance matrix of size n_samples x n_samples
def dist_matrix(ts_query, ts_index):
    m = np.zeros((len(ts_query), len(ts_index)))
    for i, x in enumerate(ts_query):
        for j, y in enumerate(ts_index):
            #alignment = r.dtw(x, y, distance_only=True)
            #dist = alignment.rx('distance')[0][0]
            dist = mlpy.dtw_std(x, y, dist_only=True)
            m[i, j] = dist

    return m

def estimate(X_train, y_train, X_test, y_test, out, estimator):
    estimator.fit(X_train, y_train)
    y_prob_train = estimator.predict_proba(X_train)
    y_prob_test = estimator.predict_proba(X_test)
    y_prob = np.vstack((y_prob_train, y_prob_test))
    np.savetxt(out, y_prob)
