import numpy as np

from sklearn.metrics import roc_auc_score, roc_curve, confusion_matrix

def sensitivity(m):
    # Confusion matrix i, j: Observed i, predicted j
    tp = m[1, 1]
    fn = m[1, 0]
    return float(tp)/(tp + fn)

def specificity(m):
    tn = m[0, 0]
    fp = m[0, 1]
    return float(tn)/(tn + fp)

def best_threshold(y_test, y_probs):
    # Returns the threshold that maximizes sensitivity + specificity
    _, _, thresholds = roc_curve(y_test, y_probs, pos_label=1)
    sensitivities = []
    specificities = []
    for p in thresholds:
        y_pred = y_probs > p
        m = confusion_matrix(y_test, y_pred)
        tpr = sensitivity(m)
        tnr = specificity(m)
        sensitivities.append(tpr)
        specificities.append(tnr)

    averages = (np.array(sensitivities) + np.array(specificities))/2
    best_p = thresholds[np.argmax(averages)]

    return best_p