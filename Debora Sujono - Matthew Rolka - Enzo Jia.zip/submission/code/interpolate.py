import glob
import re
import sys

import numpy as np
import pandas as pd

from sklearn import neighbors
from util import to_series

ts_feats = {feat: i for i, feat in enumerate(['Albumin',
    'ALP',
    'ALT',
    'AST',
    'Bilirubin',
    'BUN',
    'Cholesterol',
    'Creatinine',
    'DiasABP',
    'FiO2',
    'GCS',
    'Glucose',
    'HCO3',
    'HCT',
    'HR',
    'K',
    'Lactate',
    'Mg',
    'MAP',
    'MechVent',
    'Na',
    'NIDiasABP',
    'NIMAP',
    'NISysABP',
    'PaCO2',
    'PaO2',
    'pH',
    'Platelets',
    'RespRate',
    'SaO2',
    'SysABP',
    'Temp',
    'TroponinI',
    'TroponinT',
    'Urine',
    'WBC',
    'Weight'])
}

gen_feats = {feat: i for i, feat in enumerate(['Age',
    'Gender', #(0: female, or 1: male)
    'Height'])
}

cat_feats = {
    'ICUType' #(1: Coronary Care Unit, 2: Cardiac Surgery Recovery Unit, 3: Medical ICU, or 4: Surgical ICU)
}

data_dir = sys.argv[1]
out_dir = sys.argv[2]
t = 24

# Iterate over each patient record
for i, filename in enumerate(glob.iglob(data_dir + '/*.txt')):
    if i % 10 == 0: sys.stdout.write('\rProcessing record %d/%d' % (i, 4000))

    # Parse record id
    match = re.search('\/(\d+)\.txt', filename)
    rec_id = int(match.group(1))

    x_gen = np.full((t, len(gen_feats)), np.nan)
    x_cat = np.zeros((t, len(cat_feats) * 4))
    x_ts = np.full((t, len(ts_feats)), np.nan)

    df = pd.read_csv(filename)
    grouped = df.groupby('Parameter')

    # Iterate over each feature
    for feat, feat_df in grouped:
        # Read time series features
        if feat in ts_feats:
            ts = to_series(feat_df)
            try:
                x_ts[:, ts_feats[feat]] = ts
            except:
                print rec_id
                sys.exit()

        # Read static features
        elif feat in gen_feats:
            val = float(feat_df['Value'])
            if val >= 0: x_gen[:, gen_feats[feat]] = [val] * t
    
        # Read and one-hot-encode ICUType feature
        elif feat in cat_feats:
            j = int(feat_df['Value']) - 1
            x_cat[:, j] = [1] * t

    X = np.hstack((x_gen, x_cat, x_ts))
    out = '%s/%s.txt' % (out_dir, rec_id)
    np.savetxt(out, X)

sys.stdout.write('\rProcessing record %d/%d' % (i + 1, 4000))
print
