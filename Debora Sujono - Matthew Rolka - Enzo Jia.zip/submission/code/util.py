import eval_util

import numpy as np
import pandas as pd

from sklearn.metrics import roc_auc_score, confusion_matrix
from sklearn.preprocessing import Imputer, OneHotEncoder, StandardScaler

def to_datetime(s):
    h, m = [int(d) for d in s.split(':')]
    d = (h / 24) + 1
    h = h % 24
    """
    if h < 24:
        d = 1
    else:
        d = 2
        h -= 24
    """

    return pd.to_datetime('1-%d-2015 %d:%d' % (d, h, m))

def to_datetime_idx(times):
    datetimes = []
    for t in times:
        s = to_datetime(t)
        datetimes.append(s)

    return datetimes

def to_series(df):
    ts = df['Value'].copy()
    ts[ts < 0] = np.nan
    ts.index = to_datetime_idx(df['Time'])

    start_idx = to_datetime('00:01')
    end_idx = to_datetime('48:00')

    if to_datetime('00:00') in ts.index:
        start_val = np.mean(ts[to_datetime('00:00')])
        ts.drop(to_datetime('00:00'), inplace=True)
        ts = ts.append(pd.Series([start_val], index=[start_idx]))
    
    if min(ts.index) > start_idx:
        ts = ts.append(pd.Series([np.nan], index=[start_idx]))
    
    if max(ts.index) < end_idx:
        ts = ts.append(pd.Series([np.nan], index=[end_idx]))

    # Resample to 24 2-hour time steps
    try:
        ts = ts.resample('2H', how='mean', closed='right')
    except:
        print len(ts.index), len(df['Value'])
        print df
        for i in ts.index:
            print '-', ts[i]
        return

    assert len(ts) == 24

    # Linearly interpolate to fill in missing data
    ts = ts.interpolate()
    ts = ts.fillna(method='backfill')

    return ts

def create_summary_stat_mat(data_dir, rec_ids, ts_feats, fn, dtype):    
    X_raw = []    

    # Reading data
    for rec_id in rec_ids:
        filename = '%s/%s.txt' % (data_dir, rec_id)
        f = open(filename, 'r')
        f.next() # skip header
    
        # Read features
        x = np.full(len(ts_feats), np.nan)
        raw_ts = {}
    
        for line in f:
            # Each line consists of timestamp, feature name, feature value
            t, feat, val = line.split(',')
        
            # Store raw time series features to extract summary stats later
            if feat in ts_feats:        
                val = dtype(val)
                if val >= 0:
                    if feat in raw_ts:
                        raw_ts[feat].append(val)
                    else:
                        raw_ts[feat] = [val]
            
        # Extract summary stats (first, min, mean, max, last, and length)
        # of each ts feature from raw_ts
        for feat, ts in raw_ts.iteritems():    
            j = ts_feats[feat]
            x[j] = fn(ts)

        X_raw.append(x)
        f.close()

    # Impute missing values
    X = Imputer().fit_transform(X_raw)
    assert not np.sum(np.isnan(X))

    # Scale features
    X = StandardScaler().fit_transform(X)

    return (X, np.array(X_raw))

def create_gen_mat(data_dir, rec_ids, gen_feats, dtype):
    X_raw = []    

    # Reading data
    for rec_id in rec_ids:
        filename = '%s/%s.txt' % (data_dir, rec_id)
        f = open(filename, 'r')
        f.next() # skip header
    
        # Read features
        x = np.full(len(gen_feats), np.nan)
    
        for line in f:
            # Each line consists of timestamp, feature name, feature value
            t, feat, val = line.split(',')
        
            # Read static feature
            if feat in gen_feats:
                val = dtype(val)
                if val >= 0: x[gen_feats[feat]] = val

        X_raw.append(x)
        f.close()

    # Make sure level starts at 0
    X_raw = np.array(X_raw)
    _, ncol = X_raw.shape
    for j in range(ncol):
        levels = set(X_raw[:, j])
        offset = min(levels)
        if offset > 0:
            X_raw[:, j] -= offset

    # Impute missing values
    X = Imputer(strategy='most_frequent').fit_transform(X_raw)
    assert not np.sum(np.isnan(X))

    return (X, np.array(X_raw))

def run_experiment(X_train, y_train, X_test, y_test, clf, penalties, cat_cols):
    # Impute missing values
    # using mode for categorical and mean for remaining features
    print 'Imputing missing values'
    
    X_train_cat = X_train[:, cat_cols]
    X_test_cat = X_test[:, cat_cols]
    imputer = Imputer(strategy='most_frequent').fit(X_train_cat)
    X_train_cat = imputer.transform(X_train_cat)
    X_test_cat = imputer.transform(X_test_cat)

    X_train_ord = np.delete(X_train, cat_cols, 1)
    X_test_ord = np.delete(X_test, cat_cols, 1)
    imputer = Imputer().fit(X_train_ord)
    X_train_ord = imputer.transform(X_train_ord)
    X_test_ord = imputer.transform(X_test_ord)

    X_train = np.hstack((X_train_cat, X_train_ord))
    X_test = np.hstack((X_test_cat, X_test_ord))
    assert not np.sum(np.isnan(X_train))
    assert not np.sum(np.isnan(X_test))

    # One-hot-encode categorical features
    encoder = OneHotEncoder(categorical_features=cat_cols, sparse=False).fit(X_train)
    X_train = encoder.transform(X_train)
    X_test = encoder.transform(X_test)
    
    # Scale features
    print 'Scaling features'
    scaler = StandardScaler().fit(X_train)
    X_train = scaler.transform(X_train)
    X_test = scaler.transform(X_test)
    
    # Classify
    print 'Running experiment'
    scores = []
    for c in penalties:
        #print 'C:', c
        #clf.C = c
        clf.n_estimators = c
        clf.fit(X_train, y_train)

        y_probs = clf.predict_proba(X_test)[:, 1]
        p = eval_util.best_threshold(y_test, y_probs)
        y_pred = y_probs > p
        m = confusion_matrix(y_test, y_pred)

        auc = roc_auc_score(y_test, y_probs, average=None)
        sensitivity = eval_util.sensitivity(m)
        specificity = eval_util.specificity(m)

        """
        # Random
        y_rand = np.random.binomial(1, np.mean(y_train), len(X_test))
        m_rand = confusion_matrix(y_test, y_rand)
        print '%% positive:', np.mean(y_train)
        print 'Random AUC:', roc_auc_score(y_test, y_rand, average=None)
        print 'Random sensitivity:', eval_util.sensitivity(m_rand)
        print 'Random specificity:', eval_util.specificity(m_rand)
        print

        print 'Optimal p:', p
        print 'Model AUC:', auc
        print 'Model sensitivity:', sensitivity
        print 'Model specificity:', specificity
        print
        """

        scores.append([p, auc, sensitivity, specificity])

    return scores
