import sys
import util

import numpy as np

from sklearn.svm import SVC
from sklearn.linear_model import LogisticRegression
from sklearn.naive_bayes import GaussianNB
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier, AdaBoostClassifier, GradientBoostingClassifier

from sklearn.cross_validation import KFold

# Modify experimental settings
data_file = sys.argv[1]
out_file = sys.argv[2] 
cat_cols = [0]
label_idx = -1
#clf = LogisticRegression(class_weight='balanced')
clf = SVC(class_weight='balanced', probability=True)
#clf = GaussianNB()
#clf = RandomForestClassifier(criterion='entropy', class_weight='balanced')
#clf = GradientBoostingClassifier(n_estimators=100, loss='exponential')
c = [100] #[10, 50, 100, 500, 1000, 5000] #[0.1, 0.5, 1, 2, 5, 10]

# Define features
gen_feats = [
    'Age',
    'Gender', #(0: female, or 1: male)
    'Height'
]

cat_feats = [
    'ICUType' #(1: Coronary Care Unit, 2: Cardiac Surgery Recovery Unit, 3: Medical ICU, or 4: Surgical ICU)
]

ts_feats = [
    'Albumin',
    'ALP',
    'ALT',
    'AST',
    'Bilirubin',
    'BUN',
    'Cholesterol',
    'Creatinine',
    'DiasABP',
    'FiO2',
    'GCS',
    'Glucose',
    'HCO3',
    'HCT',
    'HR',
    'K',
    'Lactate',
    'Mg',
    'MAP',
    'MechVent',
    'Na',
    'NIDiasABP',
    'NIMAP',
    'NISysABP',
    'PaCO2',
    'PaO2',
    'pH',
    'Platelets',
    'RespRate',
    'SaO2',
    'SysABP',
    'Temp',
    'TroponinI',
    'TroponinT',
    'Urine',
    'WBC',
    'Weight'
]

# Get a mapping from feature name to index
gen_feat_idx = {f: i for i, f in enumerate(gen_feats)}
ts_feat_idx = {f: i for i, f in enumerate(ts_feats)}

# Read data
print 'Reading data'
data = np.genfromtxt(data_file)
X = np.delete(data, label_idx, 1) # Feature matrix
y = data[:, label_idx]            # Label vector

print X.shape, y.shape            # Dimensionality of X and y
print np.mean(y)                  # % positive label
print np.mean(np.isnan(X))        # % missing

"""
# Random
y_rand = np.random.binomial(1, np.mean(y_train), len(X_test))
m_rand = confusion_matrix(y_test, y_rand)
print 'Random AUC:', roc_auc_score(y_test, y_rand, average=None)
print 'Random sensitivity:', eval_util.sensitivity(m_rand)
print 'Random specificity:', eval_util.specificity(m_rand)
print
"""

# Run 5-fold cv
scores = []
kf = KFold(len(y), n_folds=5, shuffle=True)
for k, (train_index, test_index) in enumerate(kf):
    print 'Fold', k + 1
    X_train, X_test = X[train_index], X[test_index]
    y_train, y_test = y[train_index], y[test_index]

    scores.append(util.run_experiment(X_train, y_train, X_test, y_test,
                                      clf, c, cat_cols))
    print

avg_scores = np.mean(scores, axis=0)
print avg_scores
np.savetxt(out_file, avg_scores)
