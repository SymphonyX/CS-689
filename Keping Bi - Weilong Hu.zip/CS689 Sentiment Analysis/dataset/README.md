IMDB dataset is a public dataset, which can be downloaded from the following link.

http://ai.stanford.edu/~amaas/data/sentiment/

Dataset can also be downloaded from the competition in Kaggle. 

https://www.kaggle.com/c/word2vec-nlp-tutorial/data

Data in the above two dataset is in different format, in our project we use both.