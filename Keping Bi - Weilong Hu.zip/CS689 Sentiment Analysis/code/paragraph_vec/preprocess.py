import sys

def norm_text(sen):
    sen = sen.replace('<br />', '')
    new_sen = []
    for ch in sen:
        if ch.isdigit() or ch.isalpha():
            new_sen.append(ch)
        else:
            new_sen.append(' ')
    sen = ' '.join(''.join(new_sen).split())
    return sen.lower()

def process(fname, fout):
    f = file(fname, 'r')
    f.readline()
    labels = []
    #reviews = []
    fr = file(fout, 'w')
    for line in f:
        segs = line.strip('\r\n').split('\t')
        #label = int(segs[1])
        #review = norm_text(segs[2])
        review = norm_text(segs[1])
        fr.write("%s\n" % review)
        #print review
        #print >> fr, review
        #labels.append(label)
        #reviews.append(review)
    f.close()
    fr.close()
    f = file(fout+'.label', 'w')
    for label in labels:
        print >> f, label
    f.close()

def main():
    if len(sys.argv) < 3:
        sys.exit(-1)
    process(sys.argv[1], sys.argv[2])

if __name__ == "__main__":
    main()
