from __future__ import print_function
import numpy as np

from keras.utils import np_utils
from keras.models import Sequential
from keras.layers.core import Dense, Dropout, Activation
from keras.layers.core import Layer
import imdb_doc2vec
import argparse
import time
import sys

max_features = 20000
#max_features = 40000
#maxlen = 100  # cut texts after this number of words (among top max_features most common words)
maxlen = 200  # cut texts after this number of words (among top max_features most common words)
batch_size = 32

print('Loading data...')
#single model
#(X_train, y_train), (X_test, y_test) = imdb_doc2vec.load_vecs('all.model.doc2vec')
#two model combine
parser = argparse.ArgumentParser()
start = time.time()
(X_train_a, y_train), (X_test_a, y_test) = imdb_doc2vec.load_vecs('all.model.dbow.doc2vec')
end = time.time()
print((end - start), "s loading dbow")
start = time.time()
(X_train_b, y_train), (X_test_b, y_test) = imdb_doc2vec.load_vecs('all.model.dmm.ori.doc2vec')
end = time.time()
print((end - start), "s loading dmm")
#(X_train_b, y_train), (X_test_b, y_test) = imdb_doc2vec.load_vecs('all.model.dmc.doc2vec')
#(X_train_a, y_train), (X_test_a, y_test) = imdb_doc2vec.load_vecs('all.model.dbow.spl.doc2vec')
#(X_train_b, y_train), (X_test_b, y_test) = imdb_doc2vec.load_vecs('all.model.dmc.spl.doc2vec')
X_train = np.concatenate((X_train_a, X_train_b), axis=1)
X_test = np.concatenate((X_test_a, X_test_b), axis=1)
vec_size = len(X_train[0])
#for x in X_train:
#    print("x", len(x), file=sys.stderr)
#print("len y", len(y_train), file=sys.stderr)
#for y in y_test:
#    print("y", y, file=sys.stderr)

print(len(X_train), 'train sequences')
print(len(X_test), 'test sequences')

print('X_train shape:', X_train.shape)
print('X_test shape:', X_test.shape)

print('Build model...')
model = Sequential()
model.add(Dense(128, input_dim=vec_size))
model.add(Activation('tanh'))
model.add(Dropout(0.5))
#model.add(Dense(1, input_dim=vec_size))
model.add(Dense(1))
model.add(Activation('sigmoid'))

# try using different optimizers and different optimizer configs
model.compile(loss='binary_crossentropy',
              optimizer='adam',
              class_mode="binary")

print("Train...")
model.fit(X_train, y_train, batch_size=batch_size, nb_epoch=20,
          validation_data=(X_test, y_test), show_accuracy=True)
score, acc = model.evaluate(X_test, y_test,
                            batch_size=batch_size,
                            show_accuracy=True)
print('Test score:', score)
print('Test accuracy:', acc)

