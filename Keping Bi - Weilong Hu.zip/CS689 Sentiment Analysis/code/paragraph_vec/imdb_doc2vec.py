from gensim.models import doc2vec
#from sklearn import datasets, neighbors, linear_model
from sklearn.linear_model import LogisticRegression
import numpy as np
import multiprocessing
from random import shuffle


def load_data(train_file='all.train.review', test_file='test.review'):
    #train_file = 'all.train.review'
    #test_file = 'test.review'
    #vec_size = 100
    def read_label(fname):
        f = file(fname, 'r')
        y_train = []
        for line in f:
            y_train.append(int(line.strip('\r\n')))
        f.close()
        return y_train
    y_train = read_label(train_file+'.label')
    #train_number = len(y_train)
    y_test = read_label(test_file+'.label')
    #test_number = len(y_test)
    test_sen = doc2vec.TaggedLineDocument(test_file)
    #X_test = [model.infer_vector(sen.words) for sen in test_sen]
    train_sen = doc2vec.TaggedLineDocument(train_file)
    return (train_sen, y_train), (test_sen, y_test)

def eval_regression(model, y_train, test_sen, y_test, vec_size = 100):
    train_number = len(y_train)
    test_number = len(y_test)
    X_train = []
    for i in xrange(train_number):
        X_train.append(model.docvecs[i])
    X_train = np.array(X_train).reshape((train_number, vec_size))
    constant = np.ones((train_number,1))
    X_train = np.concatenate((X_train, constant), axis=1)
    lr = LogisticRegression()
    lr.fit(X_train, y_train)
    X_test = [model.infer_vector(sen.words) for sen in test_sen]
    constant = np.ones((test_number,1))
    X_test = np.concatenate((X_test, constant), axis=1)
    #C = lr.predict(X_train)
    #count = sum([1 if C[i] == y_train[i] else 0 for i in range(train_number)])
    #print (count + 0.0) / train_number
    print "train acc",lr.score(X_train, y_train)
    print "test acc",lr.score(X_test, y_test)

def train_doc2vec(vec_size=100):
    (train_sen, y_train), (test_sen, y_test) = load_data()
    cores = multiprocessing.cpu_count()
    #model = doc2vec.Doc2Vec(size=vec_size, window=8, min_count=5, workers=12)
    #model = doc2vec.Doc2Vec(dm=1, dm_concat=1, size=100, window=5, negative=5, hs=0, min_count=2, workers=cores)
    #model = doc2vec.Doc2Vec(dm=1, dm_concat=1, size=vec_size, sample=1e-4, window=10, negative=25, hs=0, min_count=2, workers=cores)
    #model = doc2vec.Doc2Vec(dm=0, size=vec_size, window=10, negative=5, hs=0, min_count=2, workers=cores)
    #model = doc2vec.Doc2Vec(dm=0, size=vec_size, sample=1e-4, negative=25, hs=0, min_count=2, workers=20)
    model = doc2vec.Doc2Vec(dm=1, dm_mean=1, size=vec_size, window=10, negative=5, hs=0, min_count=2, workers=cores)
    model.build_vocab(train_sen)
    alpha, min_alpha, passes = (0.025, 0.001, 20)
    alpha_delta = (alpha - min_alpha) / passes
    for epoch in range(passes):
        print "epoch:%d" % epoch
        #shuffle(train_sen) #wrong
        model.alpha, model.min_alpha = alpha, alpha
        model.train(train_sen)
        alpha -= alpha_delta
        eval_regression(model, y_train, test_sen, y_test, vec_size)
        #model.alpha -= 0.002  # decrease the learning rate
        #model.min_alpha = model.alpha  # fix the learning rate, no decay
    #model.save('all.model.dmm.doc2vec')
    #model.save('all.model.dmc.spl.doc2vec')
    #model.save('all.model.dmc.doc2vec')
    #model.save('all.model.dbow.400.doc2vec')
    model.save('all.model.dmm.400.doc2vec')
    #model = doc2vec.Doc2Vec.load('my_model.doc2vec')
    '''
    '''

    #inferred_docvec = model.infer_vector(['this','is','a','test'])
    #print model.docvecs.most_similar([inferred_docvec], topn=3)
    #print model.most_similar("good")
    #print model.docvecs[24999]

def load_vecs(model_file):
    (train_sen, y_train), (test_sen, y_test) = load_data()
    train_number = len(y_train)
    #test_number = len(y_test)
    model = doc2vec.Doc2Vec.load(model_file)
    X_train = []
    for i in xrange(train_number):#the first 25000 are labeled, the latter 50000 are unlabeled
        X_train.append(model.docvecs[i])
    #X_train = np.array(X_train).reshape((train_number, vec_size))
    X_train = np.array(X_train)
    X_test = [model.infer_vector(sen.words) for sen in test_sen]
    X_test = np.array(X_test)
    return (X_train, y_train), (X_test, y_test)


if __name__ == '__main__':
    train_doc2vec(400)


