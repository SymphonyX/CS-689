Codes for this part are dependent on gensim package, keras and scikit-learn

pip install -U gensim

pip install keras==0.2.0

pip install -U scikit-learn

These codes process data downloaded from https://www.kaggle.com/c/word2vec-nlp-tutorial/data

a. preprocess.py
b. imdb_doc2vec.py # generate single paragraph vector model
c. imdb_mlp.py # combination of two paragraph vector model, then use Logistic Regression or Multiple-Layer Perceptron to classify.
