This is the files which uses the bag of words with TF-IDF to generate the feature vector. It contains 6 files in this folder. The following is the explanation:
These codes uses data from https://www.kaggle.com/c/word2vec-nlp-tutorial/data
To run, you need to install some packages
nltk, sklearn, pandas

	part1nbtfidf.py  --> use BOW+TFIDF+NB to predict the accuracy;
	part1rftfidf.py  --> use BOW+TFIDF+RF to predict the accuracy;
	part1lrtfidf.py  --> use BOW+TFIDF+LR to predict the accuracy;
	part1svmtfidf.py --> use BOW+TFIDF+SVM with linear kernal to predict the accuracy;
	part1rfCVtfidf.py  --> use BOW+TFIDF+RF with cross validation(cv=5) to predict the accuracy;
	part1lrCVtfidf.py  --> use BOW+TFIDF+LR with cross validation(cv=5) to predict the accuracy;
	
