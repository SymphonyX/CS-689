This is the files which uses the bag of words with TF-IDF to generate the feature vector. It contains 6 files in this folder. The following is the explanation:
These codes uses data from https://www.kaggle.com/c/word2vec-nlp-tutorial/data
To run, you need to install some packages
nltk, sklearn, pandas

This is the files which uses the word2Vec to generate the feature vector. It contains 3 files in this folder. The following is the explanation:

	part2rf.py  --> use word2Vec + RF to predict the accuracy;
	part2svm.py --> use word2Vec + SVM to predict the accuracy;
	part2lr.py  --> use word2Vec + LR to predict the accuracy;
	
