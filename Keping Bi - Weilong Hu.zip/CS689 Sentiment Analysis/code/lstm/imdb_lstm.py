'''Train a LSTM on the IMDB sentiment classification task.

The dataset is actually too small for LSTM to be of any advantage
compared to simpler, much faster methods such as TF-IDF+LogReg.

'''

from __future__ import print_function
import numpy as np
np.random.seed(1337)  # for reproducibility

import theano.tensor as T
from keras.preprocessing import sequence
from keras.utils import np_utils
from keras.models import Sequential
from keras.layers.core import Dense, Dropout, Activation
from keras.layers.core import Layer
from keras.layers.embeddings import Embedding
from keras.layers.recurrent import LSTM, GRU
from keras.layers.convolutional import Convolution1D, MaxPooling1D
#from keras.datasets import imdb
#import sys
#sys.path.append('../keras/datasets/')
import imdb

max_features = 20000
#max_features = 5000
#max_features = 40000
#maxlen = 100  # cut texts after this number of words (among top max_features most common words)
maxlen = 200  # cut texts after this number of words (among top max_features most common words)
batch_size = 32

print('Loading data...')
#(X_train, y_train), (X_test, y_test) = imdb.load_data(path="imdb_all.pkl",nb_words=max_features,
(X_train, y_train), (X_test, y_test) = imdb.load_data(nb_words=max_features,
                                                      test_split=0.5)
#for x in X_train:
#    print("x", len(x), file=sys.stderr)
#print("len y", len(y_train), file=sys.stderr)
#for y in y_test:
#    print("y", y, file=sys.stderr)

print(len(X_train), 'train sequences')
print(len(X_test), 'test sequences')

print("Pad sequences (samples x time)")
X_train = sequence.pad_sequences(X_train, maxlen=maxlen)
X_test = sequence.pad_sequences(X_test, maxlen=maxlen)
#for x in X_train:
#    print("x\t",x, file=sys.stderr)
print('X_train shape:', X_train.shape)
print('X_test shape:', X_test.shape)

'''
new_train = []
for spl in X_train:
    fea_vec = np.zeros((maxlen, max_features))
    for j in xrange(maxlen):
        if spl[j] > 0 and spl[j] < max_features:
            fea_vec[j][spl[j]] = 1
    new_train.append(fea_vec)
X_train = new_train

new_test = []
for spl in X_test:
    fea_vec = np.zeros((maxlen, max_features))
    for j in xrange(maxlen):
        if spl[j] > 0 and spl[j] < max_features:
            fea_vec[j][spl[j]] = 1
    new_test.append(fea_vec)
X_test = new_test
'''

print('Build model...')
model = Sequential()
model.add(Embedding(max_features, 128, input_length=maxlen))
model.add(LSTM(64))  # try using a GRU instead, for fun
#model.add(LSTM(128, input_dim=max_features, input_length=maxlen))  # try using a GRU instead, for fun
model.add(Dropout(0.25))
#model.add(GlobalPooling())
model.add(Dense(1))
model.add(Activation('sigmoid'))

# try using different optimizers and different optimizer configs
model.compile(loss='binary_crossentropy',
              optimizer='adam',
              class_mode="binary")

print("Train...")
#model.fit(X_train, y_train, batch_size=batch_size, nb_epoch=3,
model.fit(X_train, y_train, batch_size=batch_size, nb_epoch=10,
          validation_data=(X_test, y_test), show_accuracy=True)
score, acc = model.evaluate(X_test, y_test,
                            batch_size=batch_size,
                            show_accuracy=True)
print('Test score:', score)
print('Test accuracy:', acc)

