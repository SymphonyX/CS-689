Codes for this part are dependent on keras

pip install keras==0.2.0

These codes process the data downloaded from http://ai.stanford.edu/~amaas/data/sentiment/
a. preprocess2pickle.py
b. imdb_lstm.py

