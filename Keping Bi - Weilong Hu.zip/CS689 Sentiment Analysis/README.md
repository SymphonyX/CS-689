Final Project for CS689 Machine Learning
Keping Bi and Weilong Hu

Code, dataset and report are included in this folder.

In the folder of code, there are four folders, corresponding to the methods mentioned in the report.

bow+tfidf ==> bag of words with tfidf as feature value + different classification methods
averaged_word2vec ==> averaged word vectors + different classification methods
paragraph_vec ==> paragraph vectors + logistic regression and Multiple Layer Perceptron
lstm ==> Long Short-Term Memory 

In each folder, there is a Readme file describing the code.
