from vectors.utils import Corpus
import os
import pdb

corpus = Corpus("data/GOP_REL_ONLY.csv", keep_order=True)

for i, doc in enumerate(corpus.docs):
    print "[*] breaking off {}".format(i)
    with open("docs/" + str(i), "w") as the_file:
        the_file.write(" ".join(doc))
