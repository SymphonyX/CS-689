import ipdb
import itertools
import pandas

from scripts.twokenize import tokenizeRawTweetText


to_avoid = [u'rt', u':', u'(', u')', u'!', u'"', u'#']
to_avoid += [u'.', u'#gopdebate', '#gop', u'the', u'#gopdebates', u'to', u'\u2026',  u',', u'a', u'is', u'of', u'and', u'in', \
            u'i',u'?', u'for', u'on', u'that', u'you', u'it',  u'was', u'&', u'about', u'this', u'be',\
            u'at', u'last', u'with', u'are']
to_avoid = set(to_avoid)

class Corpus:

    def __init__(self, loc, n=None, keep_order=False):
        '''
        Create a corpus
        '''
        self.keep_order = keep_order
        self.DF = pandas.read_csv(loc)
        self.docs = self.get_docs(n)
        self.ndocs = len(self.docs)
        self.vocab = self.get_vocab()
        wind, rev = self.get_get_word_index()
        self.windex = wind
        self.reverse_windex = rev
        self.candidates = None

        # this is set to true, keep words in order and don't delete repeat words

    def get_docs(self, n):
        t_docs = []
        candidates = []
        self.indexes = []
        for index, row in self.DF.iterrows():
            candidates.append(row['candidate'])
            # print row['candidate']
            if row['candidate'] != "No candidate mentioned" and row['relevant_yn'] == "yes" and  type(row['candidate']) != float:
                try:
                    if self.keep_order:
                        doc = tuple(i.lower() for i in tokenizeRawTweetText(row['text']))
                    else:
                        doc = tuple(i.lower() for i in set(tokenizeRawTweetText(row['text'])))
                        doc = [d for d in doc if unicode(d) not in to_avoid]
                        doc = [d for d in doc if d[0] !="@" not in to_avoid]
                        doc = [d for d in doc if "http" not in d]
                    t_docs.append(doc)
                    self.indexes.append(index)
                except UnicodeDecodeError:
                    pass
            if n is not None and len(t_docs) == n:
                return t_docs
        return t_docs

    def get_indexes(self, n):
        indexes = []
        for index, row in self.DF.iterrows():
            # print row['candidate']
            if row['candidate'] != "No candidate mentioned" and row['relevant_yn'] == "yes" and  type(row['candidate']) != float:
                try:
                    if self.keep_order:
                        doc = tuple(i.lower() for i in tokenizeRawTweetText(row['text']))
                    else:
                        doc = tuple(i.lower() for i in set(tokenizeRawTweetText(row['text'])))
                        doc = [d for d in doc if unicode(d) not in to_avoid]
                        doc = [d for d in doc if d[0] !="@" not in to_avoid]
                        doc = [d for d in doc if "http" not in d]
                    indexes.append(index)
                except UnicodeDecodeError:
                    pass
            if n is not None and len(t_docs) == n:
                return indexes
        return indexes

    def get_vocab(self):
        '''
        Gets the tweets
        '''
        words = [i for i in itertools.chain(*self.docs)]
        return set(words)

    def get_get_word_index(self):
        '''
        Return an index of words to index location
        '''
        WINDEX = {}
        REV_WINDEX = {}

        for index, word in enumerate(self.vocab):
            WINDEX[word] = index
            REV_WINDEX[index] = word

        return WINDEX, REV_WINDEX
