import pickle
import pdb
from scipy import spatial
from vectors.utils import Corpus

corpus = Corpus("data/GOP_REL_ONLY.csv")

R = pickle.load(open("R.p", "r"))

pt = R[corpus.windex["christie"]]

print R[corpus.windex["christie"]]
print R[corpus.windex["trump"]]

items = spatial.KDTree(R).query(pt, 5)

for i in items[1]:
    print corpus.reverse_windex[i]