from nltk.tokenize import TweetTokenizer
import pandas as pd
import numpy as np
import igraph
import seaborn as sns
from collections import defaultdict

sns.set(style='whitegrid')

class bcolors:
    HEADER = '\033[95m'
    OKBLUE = '\033[94m'
    OKGREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'


def tokenize(df):
    tknzr = TweetTokenizer(strip_handles=True, reduce_len=True, preserve_case=False)
    to_avoid = ['rt', ':', '(', ')', '!', '"', '#']
    to_avoid += [u'.', u'#gopdebate', '#gop', u'the', u'#gopdebates', u'to', u'\u2026',  u',', u'a', u'is', u'of', u'and', u'in', \
                 u'i',u'?', u'for', u'on', u'that', u'you', u'it',  u'was', u'&', u'about', u'this', u'be',\
                 u'at', u'last', u'with', u'are']
    to_avoid = set(to_avoid)
    def tokenizer(x):
        partial = tknzr.tokenize(x)
        return {y : 1 for y in partial if  not y in to_avoid and not '/' in y}
    return df.text.apply(tokenizer)

def make_categories(max, idx):
    idToCategory = defaultdict(int)
    categoriesToId = defaultdict(list)
    last = 0
    for id, value in max.iteritems():
        other = idx[id]
        otherIn = other in idToCategory
        selfIn = id in idToCategory
        if otherIn and (not selfIn):
            cat = idToCategory[other]
            idToCategory[id] = cat
            categoriesToId[cat].append(other)
        elif (not otherIn) and selfIn:
            cat = idToCategory[id]
            idToCategory[other] = cat
            categoriesToId[cat].append(id)
        elif not (otherIn or selfIn):
            idToCategory[id] = idToCategory[other] = last
            categoriesToId[last] += [id, other]
            last += 1
        else:
            cat1, cat2 = idToCategory[id], idToCategory[other]
            cat  = cat1
            for element in categoriesToId[cat2]:
                idToCategory[element] = cat
            categoriesToId[cat].extend(categoriesToId[cat2])
    return pd.Series(idToCategory, dtype='category')

def make_tweeter_space(tweets_to_word):
    factor = (np.log10(tweets_to_word.index.size) - tweets_to_word.sum().apply(np.log10))
    df = tweets_to_word*factor
    df = df.div(df.apply(np.linalg.norm, axis=1), axis=0)
    tweets_space = df.dot(df.T)
    return tweets_space - np.identity(tweets_space.values.shape[0])

def tweet_space_from_df(df):
    tweets = tokenize(df)
    tweets_df = pd.DataFrame(tweets.values.tolist(), dtype=float, index=df.index)
    tweets_df = tweets_df.drop(tweets_df.columns[tweets_df.sum() < 10], axis=1).fillna(0)
    tweets_space = make_tweeter_space(tweets_df)
    return tweets_space

def closeness(space):
    idxmax = space.idxmax(axis=1)
    tweets_max = space.max(axis=1)
    above75 = space[(space < 0.9999) & (space > 0.65)]
    categories = make_categories(above75, idxmax)
    return categories

def graph_based(space, low_threshold = 0.65, high_threshold = 0.9999):
    binnary = (space > low_threshold) & (space < high_threshold)
    graph = igraph.Graph.Adjacency(binnary.as_matrix().tolist(), mode=igraph.ADJ_UNDIRECTED)
    clusters= graph.clusters()
    membership = pd.Series(clusters.membership, dtype='category', index=space.index)
    return membership

def print_relevants(df, membership, limit=None):
    relevants = membership.value_counts().head(10)
    for idx, _ in relevants.iteritems():
        print idx
        texts = df.ix[membership[membership== idx].index].text
        if limit:
            texts = texts.head(limit)
        print texts.values



def main():
    df = pd.read_csv('../data/GOP_REL_ONLY.csv')
    df = df[~df.text.str.lower().str.startswith('rt')]
    df = df.ix[df.text.drop_duplicates().index]

    space = tweet_space_from_df(df)
    print_relevants(df, closeness(space))
    print bcolors.OKGREEN + '*' * 60 + bcolors.ENDC
    print_relevants(df, graph_based(space))




if __name__ == '__main__':
    main()