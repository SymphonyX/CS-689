import pandas as pd
import sys
import ipdb
import pickle
import numpy as np
from vectors.utils import Corpus
from sklearn.neighbors import KDTree
from sklearn.decomposition import RandomizedPCA


if __name__ == '__main__':
    corpus = Corpus("data/GOP_REL_ONLY.csv", n=6266)
    word_doc = np.zeros((len(corpus.vocab), len(corpus.docs)))

    for di, doc in enumerate(corpus.docs):
        for wrd in corpus.docs[di]:
            word_doc[corpus.windex[wrd]][di] = 1

    pca = RandomizedPCA(n_components=100)
    pca.fit(word_doc)

    low_dim = pca.transform(word_doc)

    kdt = KDTree(low_dim, leaf_size=200, metric='euclidean')

    pickle.dump(low_dim, open("low_dim.r", "w"))
    pickle.dump(kdt, open("vecs.r", "w"))
