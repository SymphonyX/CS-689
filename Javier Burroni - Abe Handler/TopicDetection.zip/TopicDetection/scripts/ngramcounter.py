import ujson, sys
for line in sys.stdin:
    tw = ujson.loads(line)
    if 'text' not in tw: continue
    print "AUTHOR", tw['user']['screen_name'], " ||| ", tw['text']