import sys
import random
import json
from collections import defaultdict
from twokenize import tokenizeRawTweetText

def file_len(fname):
    '''
    Count the lines in the file.
    Unfortunately, required for a good sample
    '''
    counter = 0
    with open(fname) as f:
        for i, l in enumerate(f):
            counter += 1
    return counter

filen = sys.argv[1]
tweets_count = 1000

file_len = file_len(filen)

sample_lines = random.sample(range(0, file_len), tweets_count)

term_counter = defaultdict(int)

doc_counter = defaultdict(int)

with open(filen) as f:
    for i, l in enumerate(f):
        if i in sample_lines:
            twokens = tokenizeRawTweetText(l.decode('unicode-escape'))
            for token in twokens:
                term_counter[token] += 1
            twokens_set = set(twokens)
            for tok in twokens_set:
                doc_counter[tok] += 1



with open("counts/term_" + filen.split("/").pop().replace(".tsv", ".json"), 'w') as outfile:
    json.dump(term_counter, outfile)

with open("counts/doc_" + filen.split("/").pop().replace(".tsv", ".json"), 'w') as outfile:
    json.dump(doc_counter, outfile)