import matplotlib.pyplot as plt
lines = [l.replace("DEBUG:root:","").replace("\n", "") for l in open("log.out")]
plt.scatter(range(len(lines)), lines, alpha=0.5)
plt.xlim([0,None])
plt.title('Iteration by log likelyhood')
plt.xlabel('iteration')
plt.ylabel('log likelyhood')
plt.savefig('LL.png', bbox_inches='tight')