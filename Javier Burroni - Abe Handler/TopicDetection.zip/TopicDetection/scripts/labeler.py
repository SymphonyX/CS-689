import random
import glob
import json
import csv
import pdb

bills = json.load(open("data/congresstweets_consolidated.json", "r"))

command = "START"

while command != "q":
    bill = random.choice(bills.keys())
    tweets = bills[bill]
    print "\n"
    tweet = random.choice(tweets)
    print bill, tweet[0]
    command = raw_input("Is this tweet about {}?".format(bill))
    if command not in ["q", "y", "n"]:
        print "\n INVALID INPUT"
        continue
    with open("data/labels_about.txt", "a") as labeler:
        a = csv.writer(labeler, delimiter=',')
        data = [bill, command]
        if command != "q":
            a.writerow(data + tweet)