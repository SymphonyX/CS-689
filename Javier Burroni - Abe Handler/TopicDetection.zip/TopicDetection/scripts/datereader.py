import pdb
import datetime
import collections
import datetime
import random
import matplotlib.pyplot as plt
import matplotlib.pyplot as plt

onefiftys = [o.replace("\n", "") for o in open('649', 'r')]

dates_to_plot = collections.defaultdict(int)

for d in onefiftys:
    dt = datetime.datetime.strptime(d.split("\t")[1], "%Y-%m-%dT%H:%M:%S")
    dates_to_plot[str(dt.year) + "-" +  str(dt.month)] += 1

cntr = collections.Counter(dates_to_plot)

X = []
Y = []

for bucket, count in dates_to_plot.items():
    yr = int(bucket.split("-")[0])
    mo = int(bucket.split("-")[1])
    X.append(datetime.date(yr, mo, 1))
    Y.append(count)


plt.scatter(X,Y, marker="+")
# beautify the x-labels
plt.gcf().autofmt_xdate()

plt.show()