import re
import json
import pdb
from collections import defaultdict

regexes = [i.replace("\n", "") for i in open("regexes.txt", "r")]
ignore_list = set([i.replace("\n", "") for i in open("data/ignoretypes.txt")])

regexes_sorted = defaultdict(list)

'''
Simplify the regex
'''
def translate_pattern(pattern):
    pattern = pattern.replace("\\b", "")
    pattern = pattern.replace(".", "")
    pattern = pattern.replace("?", "")
    pattern = pattern.replace("B", "")
    pattern = pattern.replace("R", "")
    pattern = pattern.replace(" ", "")
    return pattern

for pattern in regexes:
    for l in open("data/congresstweets_fixed", "r"):
        items = l.replace("\n", "").split("\t")
        if items[3] not in ignore_list:
            rawtext = items[10]
            if re.search(pattern, rawtext):
                regexes_sorted[translate_pattern(pattern)].append((rawtext,items[0],items[1]))
    print pattern

with open('data/congresstweets_consolidated.json', 'w') as outfile:
    json.dump(regexes_sorted, outfile)