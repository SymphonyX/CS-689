for r in open("congresstweets", "r"):
    if r.split("\t")[3] == "en":
        print r