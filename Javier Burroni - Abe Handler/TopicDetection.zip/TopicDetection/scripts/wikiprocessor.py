import pdb
from bs4 import BeautifulSoup
soup = BeautifulSoup(open("data/List_of_bills_in_the_113th_United_States_Congress", "r"), 'html.parser')
tables = soup.find_all('table')[0:7]

for table in tables:
    rows = table.find_all("tr")
    for row in rows:
        cells = row.find_all("td")[0:3]
        if len(cells) > 1:
            realname = cells[0].text
            alternate = cells[0].text.replace("S. ", "S. B.").replace("H.R.", "H.B.")
            common_name = cells[2].text
            print "\\b" + realname.replace(".", "\.?").replace(" ", " ?") + "\\b"
            print "\\b" + alternate.replace(".", "\.?").replace(" ", " ?") + "\\b"
            # print realname + "," + alternate + "," + common_name