cd datat && wget https://en.wikipedia.org/wiki/List_of_bills_in_the_113th_United_States_Congress && cd ../
find /tweets/all.tsv/ -type f -name "2014*" -o -name "2013*" |parallel --jobs 30 --eta egrep -i -f regexes.txt > congresstweets
py english_filter.py > congresstweets_en2
cat 150 | egrep -i "congress|oppose|support|senate|bill|act|house"
find /tweets/all.tsv/ -type f -name "2014*" -o -name "2013*" | parallel --jobs 30 --eta python language_modeler.py