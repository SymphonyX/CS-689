from nltk.tokenize import TweetTokenizer
import pandas as pd
import numpy as np
import igraph
import seaborn as sns
from collections import defaultdict
from matplotlib import pyplot as plt
from scipy.misc import logsumexp
from vectors.utils import Corpus
import sys

sns.set(style='whitegrid')



def tokenize(df):
    tknzr = TweetTokenizer(strip_handles=True, reduce_len=True, preserve_case=False)
    to_avoid = ['rt', ':', '(', ')', '!', '"', '#']
    to_avoid += [u'.', u'#gopdebate', '#gop', u'the', u'#gopdebates', u'to', u'\u2026',  u',', u'a', u'is', u'of', u'and', u'in', \
                 u'i',u'?', u'for', u'on', u'that', u'you', u'it',  u'was', u'&', u'about', u'this', u'be',\
                 u'at', u'last', u'with', u'are']
    to_avoid = set(to_avoid)
    def tokenizer(x):
        partial = tknzr.tokenize(x)
        return {y : 1 for y in partial if  not y in to_avoid and not '/' in y}
    return df.text.apply(tokenizer)

def log_normalization(theta, r, b):
    return logsumexp(theta.dot(r.T).T + b, axis=0)

def gradient_b(probabilities, words_per_tweet, tweets_per_word, indicator):
    return (tweets_per_word - words_per_tweet.dot(probabilities)).reshape(tweets_per_word.shape[0], 1)/indicator.shape[1]

def log_pword(r, thetas, b):
    energy = b+theta.dot(r.T).T
    denom = logsumexp(energy, axis=0).reshape(energy.shape[1],1)
    return energy.T-denom

def choose_variables(log_rho, old, new):
    rho = np.exp(log_rho)
    binary = (np.random.rand(*rho.shape) <= rho)
    selected = binary * new + (~binary)* old
    return selected, binary

def create_random_variables(documents, words, topics):
    randn = np.random.randn
    theta =  randn(documents, topics)
    R = randn(words,topics)
    b = randn(words,1)
    return theta, R, b

def tick_r_and_b(nu, R, theta, b, words_per_tweet, tweets_per_word, expected_theta, indicator):
    delta_R = np.random.randn(*R.shape)
    R_star = R + delta_R
    delta_plus_R = R_star+R
    delta_normalization = log_normalization(theta, R_star, b) - log_normalization(theta, R, b)
    log_rho = -nu*(delta_R*delta_plus_R) + expected_theta*delta_R - \
            ((words_per_tweet/words_per_tweet.mean())*delta_normalization).mean()
    R, binary = choose_variables(log_rho, R, R_star)
    probabilities = np.exp(log_pword(R, theta, b))
    b += gradient_b(probabilities, words_per_tweet, tweets_per_word, indicator)
    return R, b, binary

def tick_theta(lamb, R, theta, b, words_per_tweet, expected_r):
    delta_theta = np.random.randn(*theta.shape)
    theta_star = delta_theta + theta
    delta_theta_plus = theta_star + theta
    delta_normalization = log_normalization(theta_star, R, b) - log_normalization(theta, R, b)
    log_rho_theta = -lamb*(delta_theta*delta_theta_plus) + (delta_theta*expected_r).values - \
            (words_per_tweet*delta_normalization).reshape(words_per_tweet.size,1)
    return choose_variables(log_rho_theta, theta, theta_star)
     

def build_indicator(tweets_df):
    indicator = (tweets_df.fillna(0) > 0)
    tweets_per_word = indicator.sum()
    indicator = indicator[tweets_per_word[tweets_per_word > 10].index]
    words_per_tweet = indicator.sum(axis=1)
    return indicator.ix[words_per_tweet[words_per_tweet > 7].index]
    

def append_to_history(history, traces, acceptance):
    history['traces'].append(R)
    history['acceptance'].append(acceptance)

def store_history(history):
    for k in history:
        values = history[k]
        for type in values:
            name = k + '_' + type
            panel = pd.Panel({x : v for x,v in enumerate(values[type])})
            panel.to_hdf('mcmc.h5', name)
            if type == 'acceptance':
                print panel.mean(axis='items').head()




if __name__ == '__main__':
    N = int(sys.argv[1]) if len(sys.argv) > 1 else None
    if N is not None:
        print 'running on {} docs'.format(N)
    corpus = Corpus("data/GOP_REL_ONLY.csv", n=N)
    indicator = pd.DataFrame.from_records([{w : 1 for w in x} for x in corpus.docs]).fillna(0)
    documents, words = indicator.shape
    nu, lamb = 0.0001, 0.0001
    topics = 5
    N = 5000
    q = 500
    k = N/q
    should_break = False
    r = k/10.0
    theta, R, b = create_random_variables(documents, words, topics)
    words_per_tweet, tweets_per_word = indicator.sum(axis=1), indicator.sum(axis=0)
    history = { 
                'R' : {'traces' : [], 'acceptance' : []}, 
                'theta' : {'traces' : [], 'acceptance' : []},
                'b' : {'traces' : [], 'acceptance' : []}
                }
    for i in range(k):
        if i % r == 0:
            print '{}%'.format((i/float(k))*100)
        expected_theta = indicator.T.dot(theta)
        for j0 in range(q):#range(q):
            R, b, binary = tick_r_and_b(nu, R, theta, b, words_per_tweet, tweets_per_word, \
                expected_theta, indicator)
        append_to_history(history['R'], R, binary)
        append_to_history(history['b'], b, binary)
        expected_r = indicator.dot(R)
        for j1 in range(q):
            theta, binary_theta = tick_theta(lamb, R, theta, b, words_per_tweet, expected_r)
        append_to_history(history['theta'], theta, binary_theta)
    store_history(history)