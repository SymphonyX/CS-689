import pandas as pd 
import numpy as np
import seaborn as sns
import ipdb
import scipy.optimize as optimize
from scipy.misc import logsumexp
from vectors.utils import Corpus
import sys

import logging
import os

try:
    os.remove("log.out")
except:
    pass

LOG_FILENAME = 'log.out'
logging.basicConfig(filename=LOG_FILENAME,
                    level=logging.DEBUG,
                    )

BETA = 25

def log_pword(r, thetas, b):
    energy = b+r.dot(thetas)
    denom = logsumexp(energy, axis=0).reshape(energy.shape[1],1)
    return energy.T-denom

def log_likelihood(r, thetas, b, indicator):
    pwords = log_pword(r, thetas, b)
    return (indicator *pwords).sum(axis=1)

def complete_log_likelihood(r, thetas, b, indicator):
    return log_likelihood(r, thetas, b, indicator).sum()

def gradient_r(r, thetas, b, indicator, words_per_tweet, prob):
    adjusted_probabilities = words_per_tweet.reshape(len(words_per_tweet),1)*prob
    estimated_delta_p = indicator - adjusted_probabilities
    estimated_change = thetas.dot(estimated_delta_p).T
    return NU*r + estimated_change/indicator.shape[0]

def gradient_b(r, thetas, b, probabilities, words_per_tweet, tweets_per_word, indicator):
    return (tweets_per_word - words_per_tweet.dot(probabilities))/indicator.shape[0]

def tick_r_and_b(subsample_size, indicator, theta, r, b):
    sample_index = np.random.choice(range(indicator.index.size), size=subsample_size, replace=False)
    sample_indicator = indicator.iloc[sample_index, :]
    sample_theta = theta[:, sample_index]
    probabilities = np.exp(log_pword(r, sample_theta, b))
    words_per_tweet, tweets_per_word = sample_indicator.sum(axis=1), sample_indicator.sum(axis=0)
    delta_r = gradient_r(r, sample_theta, b, sample_indicator, words_per_tweet, probabilities)
    delta_b = gradient_b(r, sample_theta, b, probabilities, words_per_tweet, \
                                       tweets_per_word, sample_indicator)
    r = r + 0.1*delta_r
    b = b + delta_b.reshape(*b.shape)
    return theta, r, b, ('delta_r', delta_r.mean())



def tick_theta(subsample_size, indicator, theta, r, b):
    sample_index = np.random.choice(range(indicator.columns.size), size=subsample_size, replace=False)
    sample_indicator = indicator.iloc[:, sample_index]
    sample_r = r[sample_index, :]
    sample_b = b[sample_index, :]
    probabilities = np.exp(log_pword(sample_r, theta, sample_b))
    words_per_tweet = sample_indicator.sum(axis=1)
    delta_t = gradient_theta(sample_r, theta, probabilities, sample_indicator, words_per_tweet).values
    theta = theta + 0.1*delta_t
    return theta, r, b, ('delta_t', delta_t.mean())



def optimize(indicator, theta, r, b, f):
    WINDOW = 10
    moving_average = []
    subsample_size = 10
    full_size = indicator.columns.size
    for i in range(10000):
        theta, r, b, (name, _mean) = f(subsample_size, indicator, theta, r, b)
        if (i%100)==0:
            print i
            corpus_LL = NU*(r*r).sum() + complete_log_likelihood(r, theta, b, indicator) + LAMBDA*(theta*theta).sum()
            logging.debug(corpus_LL)
            print "corpus log likelhood {}".format(corpus_LL)
            print "{} mean: {}".format(name, _mean)
            moving_average.append(corpus_LL/(full_size/float(subsample_size)))
            moving_average = moving_average[-WINDOW:]
            cv = np.std(moving_average)/np.mean(moving_average)
            print "variance of moving avg {}".format(np.var(moving_average))
            print "std of moving avg: {}".format(np.std(moving_average))
            print "mean of moving avg: {}".format(np.mean(moving_average))
            print "coefficient of variation: {}".format(cv)
        if len(moving_average) >= WINDOW and  np.abs(cv) < 0.001:
            print "converged. ending loop"
            break
    return theta, r, b


def gradient_theta(r, thetas, probabilities, indicator, words_per_tweet):
    adjusted_probabilities = words_per_tweet.reshape(len(words_per_tweet),1)*probabilities
    adjusted_change =  (indicator - indicator*adjusted_probabilities).dot(r).T
    return LAMBDA*thetas + adjusted_change/indicator.shape[1]



if __name__ == '__main__':

    N = int(sys.argv[1]) if len(sys.argv) > 1 else None
    if N is not None:
        print 'running on {} docs'.format(N)
    corpus = Corpus("data/GOP_REL_ONLY.csv", n=N)
    N = len(corpus.docs)
    R = np.random.randn(len(corpus.vocab), BETA)
    THETAS = np.random.randn(BETA, len(corpus.docs))
    B = np.random.randn(len(corpus.vocab)).reshape(len(corpus.vocab), 1)
    indicator = pd.DataFrame.from_records([{w : 1 for w in x} for x in corpus.docs]).fillna(0)
    indicator.index = corpus.indexes
    NU = -0.0001
    LAMBDA = -0.0001
    r, theta, b = R, THETAS, B
    for i in range(10):
        for f in [tick_r_and_b, tick_theta]:
            theta, r, b = optimize(indicator, theta, r, b, f)
        pd.DataFrame(b, index=indicator.columns).to_csv('csvs/B_{}.csv'.format(i))
        pd.DataFrame(r, index=indicator.columns).to_csv('csvs/R_{}.csv'.format(i))
        pd.DataFrame(theta, columns=indicator.index).to_csv('csvs/thetas_{}.csv'.format(i))
