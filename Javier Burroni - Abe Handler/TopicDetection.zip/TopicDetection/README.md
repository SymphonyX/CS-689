# Topic Analysis for the GOP Debate
Authors: Abe Handler, Javier Burroni

## files:
The files with the algorithms described in the paper are the following: 
* `Maas-Ng.py`: Maas-Ng algorithm implemented using Stochastic Gradient Descent. This program will store the vectors *R*, *b*, and *theta* in a csvs directory. Each file is correspond to a single meta-iteration. 
* `Old-Mass-Ng.py`: old version of the Maas-Ng algorithm implemented using dictionaries. Commited as documentation
* `mcmc.py`: implementation of the Maas-Ng model using a Random Walk's Metropolis-Hasting. Vectors *R*, *b*, and *theta* are stored in the `mcmc.h5` file. 
* `vector_analysis.py`: Small analysis of the mcmc's result. Similarity vectors to few words are displayed in the output, and convergence plots are stored in the `plots' directory.
* `graphs/topic.py`: Implementation of the clustering method. Both methods described in the paper are implemented in this file. When executing, it will print out the top results for each method separated with a green line of `*`
* `create_pca_vectors.py`: this script creates the intermediate files for the pca analysis. 
* `pcavecs.py`: This script requires three words: `x`, `y`, `z`. Performs computation of the form `x +  y - z` which allows to detect analogies like: _`x` is to `z` as `y` is to ..._ . And this analysis is perform using the GOP Debate database.

