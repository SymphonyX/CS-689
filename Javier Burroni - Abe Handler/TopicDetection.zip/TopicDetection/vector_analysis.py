import matplotlib
matplotlib.use('Agg')
import pandas as pd 
import numpy as np
from matplotlib import pyplot as plt
import seaborn as sns


sns.set(style='whitegrid')

def plot_traces(r):
    for name in ['abortion', 'media', 'terrorism']:
        r.major_xs(name).T.plot()
        plt.savefig('plots/{}_traces.pdf'.format(name))
        plt.clf()


def print_similarity(words, name):
    print 'similarity with: {}'.format(name)
    word_description = words.ix[name]
    similarity = words.drop(name).dot(word_description)
    similarity.sort_values(ascending=False, inplace=True)
    print similarity.head(30)
    print similarity.tail(30)
    print '*' * 20


def normalized_words(traces): 
    words =  traces.ix[traces.items[-1]]
    return words.div(words.apply(np.linalg.norm, axis=1), axis=0)





if __name__ == "__main__":
    r_traces = pd.read_hdf('mcmc.h5', 'R_traces')
    plot_traces(r_traces)
    words = normalized_words(r_traces)
    print_similarity(words, 'trump')
    print_similarity(words, 'bernie')
    print_similarity(words, 'abortion')
    print_similarity(words, 'media')
    print_similarity(words, 'terrorism')


