from __future__ import division
import pandas
import json
import pdb
import math
import nltk
import pickle
from scripts.twokenize import tokenizeRawTweetText
import argparse

parser = argparse.ArgumentParser(description='Short sample app')

parser.add_argument('-candidate', action="store", default=True)

args = parser.parse_args()

df = pandas.read_csv('data/GOP_REL_ONLY.csv')

totals = []

corpus = []

THRESHOLD = 5

STOPWORDS = [i.replace("\n", "") for i in open("data/stopwords.txt", "r")]

def get_vocab():
    all_words = []
    for index, row in df.iterrows():
        if row['candidate'] != "No candidate mentioned" and row['relevant_yn'] == "yes" and  type(row['candidate']) != float:
            try:
                if args.candidate is True:
                    bin = row['candidate'] + "-" + row['sentiment']
                else:
                    bin = row['sentiment']
                tweet_words = [i.lower() for i in tokenizeRawTweetText(row['text'])]
                all_words = all_words + tweet_words
                corpus.append((row['text'], bin))
            except UnicodeDecodeError:
                pass
    return all_words

all_words = nltk.FreqDist(w.lower() for w in get_vocab())

def document_features(tweet):
    toks = [i.lower() for i in tokenizeRawTweetText(tweet)]
    document_words = set(toks)
    features = {}
    for word in all_words:
        if all_words[word] > THRESHOLD and word not in STOPWORDS:
            features['contains({})'.format(word)] = (word in document_words)
    return features

featuresets = [(document_features(d), c) for (d,c) in corpus]

print "[*] Got features"

train = int(math.floor(len(corpus) * .8))
tests = len(corpus) - int(math.floor(len(corpus) * .8))

train_set, test_set = featuresets[tests:], featuresets[:train]

print "[*] Training"

classifier = nltk.NaiveBayesClassifier.train(train_set)

print "[*] Testing"

correct =  0
total = 0

for doc in test_set:
    if doc[1] == classifier.classify(doc[0]):
        correct += 1
    total += 1

print correct/total