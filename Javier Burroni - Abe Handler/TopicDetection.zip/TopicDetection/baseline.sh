python docbreaker.py
mallet import-dir --input ./docs --output tweets.mallet --keep-sequence --remove-stopwords
mallet train-topics  --input tweets.mallet  --num-topics 20 --optimize-interval 20 --output-state topic-state.gz  --output-topic-keys tweets_keys.txt --output-doc-topics tweets_composition.txt
