'''
Implementation of Maas/Ng
'''
from __future__ import division

from vectors.utils import Corpus
from pylru import lrudecorator
from scipy.misc import logsumexp
from multiprocessing import Pool
import sys
import pickle
import numpy as np
import pdb
import os
import scipy.optimize as optimize


@lrudecorator(10000)
def get_indicator(words):
    '''
    Returns a BETA x V matrix.
    All columns are 1 if word appears, else 0
    '''
    out = np.zeros((BETA, len(corpus.vocab)))
    for word in words:
        out[:, corpus.windex[word]] = 1
    return out

def get_pword(d):
    '''
    Returns a BETA x V matrix.
    All columns are p(word)
    '''
    out = np.zeros((BETA, len(corpus.vocab)))
    energies = R.dot(-1 * THETAS[:, d])
    denom = np.sum(np.exp(-1 * energies))
    word_probs = np.exp((-1 * energies)) / denom
    for index, word in enumerate(corpus.vocab):
        out[:, index] = word_probs[index]
    return out


def get_log_pword_fast(d):
    '''
    Returns a BETA x V matrix.
    All columns are p(word)
    '''
    energies = R.dot(-1 * THETAS[:, d])
    denom = logsumexp(-1 * energies)
    log_probs = (-1 * energies) - np.tile(denom, len(corpus.vocab))
    return log_probs


def log_p_doc_fast(d):
    indicator = get_indicator(corpus.docs[d])[0]
    p_word = get_log_pword_fast(d)
    probs = np.multiply(indicator, p_word)
    return np.sum(probs)


def log_p_corpus_fast():
    '''
    Debugger: returns overall probability of the corpus
    '''
    return sum([log_p_doc_fast(d) for d in xrange(len(corpus.docs))])


def objective(theta_d, args):
    '''
    Objective function maximized for theta

    Scikitlearn will minimize so it will push (abs) log likelhood to zero
    '''
    return abs(NU * (np.linalg.norm(R, ord="fro") ** 2) + LAMBDA * (np.linalg.norm(theta_d, ord=2) ** 2) + log_p_doc_fast(args))


def optimize_thetas():
    print "[*] Optimizing theta"
    for d in xrange(corpus.ndocs):
        THETAS[:,d] = optimize.fmin_bfgs(objective, x0=THETAS[:,d], args=(d,), maxiter=1000)


def get_diff_component(word_index, word, j):
    tally = 0
    for d in xrange(0, len(corpus.docs)):
        for doc_word in corpus.docs[d]:
            if word in corpus.docs[d]:
                indic = 1
            else:
                indic = 0
        #assert np.sum(get_pword(d)[0]) > .999
        #assert np.sum(get_pword(d)[0]) < 1.001
            scalar = [indic * THETAS[j][d] - THETAS[j][d] * get_pword(d)[0][word_index]][0]
            assert type(scalar) is np.float64
            tally += scalar
    
    energies = R.dot(THETAS[:, d])
    denom = logsumexp(-1 * energies)
    log_probs = (-1 * energies) - np.tile(denom, len(corpus.vocab))
    tmp = np.array(THETAS[:, d], copy=True)
    tmp[j] = tally
    assert tmp[j] != THETAS[:,d][j]
    new_energies = R.dot(THETAS[:, d])
    new_denom = logsumexp(-1 * new_energies)
    new_log_probs = (-1 * new_energies) - np.tile(new_denom, len(corpus.vocab))
    if indic == 1:
        assert log_probs[word_index] <= new_log_probs[word_index]
    else:
        assert log_probs[word_index] >= new_log_probs[word_index]
            # print "before the update the prob would be {}".format(word_probs[word_index])
            # print "after the update the prob would be {}".format(word_probs_new[word_index])
    return tally


def get_diff_the_dumb_way():
    diffs = np.zeros((len(corpus.vocab),BETA))
    for word_index, word in enumerate(corpus.vocab):
        for j in range(BETA):
            diffs.itemset((word_index, j), get_diff_component(word_index, word, j))
    return diffs


if __name__ == '__main__':

    import logging

    try:
        os.remove("log.out")
    except:
        pass

    LOG_FILENAME = 'log.out'
    logging.basicConfig(filename=LOG_FILENAME,
                        level=logging.DEBUG)

    try:
        N = int(sys.argv[1])
        print 'running on {} docs'.format(N)
    except:
        print 'running on whole corpus'
        N = 16655

    corpus = Corpus("data/GOP_REL_ONLY.csv", n=N)

    BETA = 25

    NU = -.00040

    LAMBDA = -1 # cost of theta

    R = np.random.rand(len(corpus.vocab), BETA)
    THETAS = np.random.rand(BETA, len(corpus.docs))

    #for index, word in enumerate(corpus.vocab):
    #    print word
    #    print corpus.reverse_windex[index]


    for round_i in range(5):

        logging.debug("round {} {}".format(round_i, log_p_corpus_fast()))

        optimize_thetas()
        logging.debug("round {} after theta optimize {}".format(round_i, log_p_corpus_fast()))

        # huge vector of docs, each of length V. components are indicators
        long_indicator = np.zeros(0)

        # huge vector of docs, each of length V. components are probabilities
        long_probs = np.zeros(0)

        # huge matrix of docs. each col has the betas for the doc. 
        BIG_THETAS = np.zeros((BETA, len(corpus.docs * len(corpus.vocab))))
        
        #set up these big things
        for d_index, d in enumerate(corpus.docs):
            if d_index % 100:
                print d_index
            long_indicator = np.append(long_indicator, get_indicator(d)[0])
            long_probs = np.append(long_probs, get_pword(d_index)[0])
            for i, word in enumerate(corpus.vocab):
                BIG_THETAS[:,i] = THETAS[:,d_index]

        diffs = BIG_THETAS.T*long_indicator[:,np.newaxis] - BIG_THETAS.T*long_probs[:,np.newaxis]

        new_R = np.zeros((len(corpus.vocab), BETA))
        for i, w in enumerate(corpus.vocab):
            new_R[i] = np.sum(diffs[i::len(corpus.vocab)], axis=0)
        naieve = get_diff_the_dumb_way()
        # pdb.set_trace()
        # assert new_R[0][0] == naieve[0][0]
        R += 2 * R * NU + 10 * get_diff_the_dumb_way()
        logging.debug("round {} after R optimize {}".format(round_i, log_p_corpus_fast()))
        
