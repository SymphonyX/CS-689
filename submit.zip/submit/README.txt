Final project for CS689 ML
****************************************************************

Keping Bi and Weilong Hu

****************************************************************

It contains four folders in this zip file:

--------------------------
Folder 1:	bow+cf   

This is the files which uses the bag of words with count frequency to generate the feature vector. It contains seven files in this folder. The following is the explanation:

	part1nb.py  --> use BOW+CF+Naive Bayes(NB) classifier to predict the accuracy;
	part1lr.py  --> use BOW+CF+Logistic Regression(LR) classifier to predict the accuracy;
	part1svm.py  --> use BOW+CF+SVM with linear classifier to predict the accuracy;
	part1rf.py  --> use BOW+CF+random forest(RF) classifier to predict the accuracy;
	part1lrCV.py  --> use BOW+CF+LR with cross validation(cv=5) to find the best penalty parameter;
	part1rfCV.py  --> use BOW+CF+RF with cross validation(cv=5) to find the best penalty parameter;


-------------------------
Folder 2:	bow+tfidf

This is the files which uses the bag of words with TF-IDF to generate the feature vector. It contains 6 files in this folder. The following is the explanation:

	part1nbtfidf.py  --> use BOW+TFIDF+NB to predict the accuracy;
	part1rftfidf.py  --> use BOW+TFIDF+RF to predict the accuracy;
	part1lrtfidf.py  --> use BOW+TFIDF+LR to predict the accuracy;
	part1svmtfidf.py --> use BOW+TFIDF+SVM with linear kernal to predict the accuracy;
	part1rfCVtfidf.py  --> use BOW+TFIDF+RF with cross validation(cv=5) to predict the accuracy;
	part1lrCVtfidf.py  --> use BOW+TFIDF+LR with cross validation(cv=5) to predict the accuracy;
	

-------------------------
Folder 3:	word2vec

This is the files which uses the word2Vec to generate the feature vector. It contains 3 files in this folder. The following is the explanation:

	part2rf.py  --> use word2Vec + RF to predict the accuracy;
	part2svm.py --> use word2Vec + SVM to predict the accuracy;
	part2lr.py  --> use word2Vec + LR to predict the accuracy;

------------------------
Folder 4:	LSTM

This is the files which uses the sequential LSTM model. It contains 3 files in this folder. These file are downloaded from http://deeplearning.net/tutorial/lstm.html#references.
The following is the explanation:

	imdb.py  --> handles the loading and preprocessing of the IMDB dataset;
	imdb_preprocess.py --> preprocessing  the IMDB dataset;
	lstm.py  --> Defines and train the lstm model to do classification;
	
Final Report.








 
