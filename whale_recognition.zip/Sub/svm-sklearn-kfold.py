# coding=utf-8
import numpy as np
from time import time
import cv2
import pandas as pd
import csv
import re
import os
#import logging
#import matplotlib.pyplot as plt

from sklearn.grid_search import GridSearchCV
#from sklearn.metrics import classification_report
#from sklearn.metrics import confusion_matrix
from sklearn.decomposition import RandomizedPCA,PCA
from sklearn.svm import SVC
from sklearn.metrics import log_loss
from sklearn.cross_validation import StratifiedKFold

os.chdir('/Users/ChenyunWu/Documents/UMass/courses/Machine_Learning/Group_Project_Whale_recognition')


def preprocess_gray_reshape(fname):
    IMG_SIZE_W = 212
    IMG_SIZE_L = 424
    pairs = pd.read_csv(fname,sep=",",skipinitialspace=True,
    quoting=csv.QUOTE_NONE,index_col=0,names=None)
    
    names = pairs.index
    answers = np.empty(shape=(names.size),dtype=np.float32)
    imgs = np.empty(shape=(names.size, IMG_SIZE_W * IMG_SIZE_L), dtype = np.float32)
    for i in range(len(names)):
        img = cv2.imread('img_data/rotated/' + names[i])
        img = cv2.resize(img,(IMG_SIZE_W,IMG_SIZE_L) )
        gray = cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
        imgs[i] = gray.reshape(1,-1)
        num = re.findall('(\d+)', pairs.values[i][0])
        answers[i] = num[0]
        
    return imgs,answers

def sub_samples(imgs,labels,indexes):
    nimgs = np.empty(shape = (len(indexes),imgs.shape[1]),dtype = np.float32)
    nlabels = np.empty(shape = len(indexes), dtype = np.float32)
    for i in range(len(indexes)):
        nimgs[i] = imgs[indexes[i]]
        nlabels[i] = labels[indexes[i]]
    return nimgs,nlabels
    
#X_train, y_train, X_test, y_test = load_data(0.2)

#read in train images and correct answers
imgs, labels = preprocess_gray_reshape("label_data/train.csv")

kernels = ['sigmoid']#['linear','rbf','poly','sigmoid']
nfolds = 5
for kernel in kernels:
    print("\n\nKernel: %s" %kernel)
    outcomes = np.empty(shape=(nfolds,9))
    
    kf = StratifiedKFold(labels, nfolds)
    k = 0
    for train_index,test_index in kf:
        print("Fold %d - %d:"%(k,nfolds))
        X_train, y_train = sub_samples(imgs, labels, train_index)
        X_test, y_test = sub_samples(imgs, labels, test_index)
        
   
        #print(X_train.shape)
        #print(len(y_train))
        
        """
        Compute a PCA (eigenfaces) on the face dataset (treated as unlabeled
        dataset): unsupervised feature extraction / dimensionality reduction
        """
        
        n_components = 200
        
        print("PCA: Extracting the top %d eigenfaces from %d faces" %(n_components, X_train.shape[0]))
        t0 = time()
        pca = RandomizedPCA(n_components=n_components, whiten=True).fit(X_train)
        t = time() - t0
        print("done in %0.3fs" % t)
        outcomes[k][0] = t
        print("PCA: Projecting the input data on the eigenfaces orthonormal basis")
        t0 = time()
        X_train = pca.transform(X_train)
        X_test = pca.transform(X_test)
        t = time() - t0
        print("done in %0.3fs\nEnd of PCA" % t)
        outcomes[k][1] = t
        
    
        ###############################################################################
        # Train a SVM classification model
        
        print("SVM: Fitting the classifier to the training set")
        t0 = time()
        param_grid = {'C': [1,5,10,100,500,1e3, 5e3],
                        'gamma': [0.0001, 0.0005, 0.001, 0.005, 0.01, 0.1,1,5,10], }
        
        np.random.seed(0)
        
       
        clf = GridSearchCV(SVC(kernel=kernel, class_weight='balanced', probability=True, random_state=0), param_grid)
        clf = clf.fit(X_train, y_train)
        t = time() - t0
        outcomes[k][2] = t
        print("training: done in %0.3fs" % t)
        print("Best estimator found by grid search:")
        print(clf.best_estimator_)
        outcomes[k][5] = clf.best_estimator_.C
        outcomes[k][6] = clf.best_estimator_.gamma
        
        t0 = time()
        y_pred = clf.predict(X_test)
        np.save('pca-svm',y_pred)
        accuracy = sum(y_pred == y_test) * 1.0 / len(y_test)
        t = time() - t0
        outcomes[k][7] = accuracy
        outcomes[k][3] = t
        print('accuracy: %f' % accuracy) 
        print("test: done in %0.3fs" % t)
        
        t0 = time()
        clf_probs = clf.predict_proba(X_test)
        logloss = log_loss(y_test, clf_probs)
        t = time() - t0
        outcomes[k][8] = logloss
        outcomes[k][4] = t
        print('log loss: %f' % logloss) 
        print("log_loss: done in %0.3fs" % t) 
        k=k+1
    
    sum_acc = 0.0
    sum_logl = 0.0
    for i in range(5):
        sum_acc = sum_acc + outcomes[i][7]
        sum_logl = sum_logl + outcomes[i][8]
    print("average accuracy and log_loss for kernel " + kernel)
    print(sum_acc / 5.0)
    print(sum_logl / 5.0)
    np.save('svm_allwhales_brotated_216*424_PCA200_' + kernel,outcomes)