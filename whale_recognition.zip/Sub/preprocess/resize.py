import cv2,sys

fpath = sys.argv[1]
img = cv2.imread(fpath)
img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
[rows, cols] = img.shape
length = min(rows, cols)
if rows > cols:
    croped_img = img[(rows-length)/2:(rows+length)/2, 0:cols]
else:
    croped_img = img[0:rows, (cols-length)/2:(cols+length)/2]

#print croped_img.shape
dim = (300, 300)

resized = cv2.resize(croped_img, dim, interpolation = cv2.INTER_AREA)
#cv2.imshow("resized", resized)
cv2.imwrite(fpath+".reshaped.jpg",resized)
cv2.waitKey(0)
