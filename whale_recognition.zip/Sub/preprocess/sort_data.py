# coding=utf-8
import os
import pandas as pd
import shutil

train = pd.read_csv('../data/train.csv', index_col='Image')

# whaleIDs = list(train['whaleID'].unique())
#
# for w in whaleIDs:
#     os.makedirs('../data/imgs_face/'+w)
#
# for image in train.index:
#     folder = train.loc[image, 'whaleID']
#     old = '../data/imgs_face/{}'.format(image)
#     new = '../data/imgs_face/{}/{}'.format(folder, image)
#     try:
#         os.rename(old, new)
#     except:
#         print('{} - {}'.format(image, folder))


path = '../data/imgs'

for l in os.listdir(path):
    d = os.path.join(path, l)
    if os.path.isfile(d):
        continue
    for pic in os.listdir(d):
        if pic.endswith('.jpg'):
            shutil.move(os.path.join(d, pic), '../data/train_imgs')



