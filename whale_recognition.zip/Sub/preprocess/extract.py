# coding=utf-8
import numpy as np
import cv2


def getHist(img, ranges):
    hist = cv2.calcHist([img], channels=[0, 1, 2], mask=None,
                        histSize=[32] * 3, ranges=ranges)
    return hist


def gen_all_segment(img_shape, window_size):
    img_x, img_y = img_shape
    # assume whale is not on the boundary of image
    for i in range(5 * window_size, img_x - 4 * window_size, window_size):
        for j in range(5 * window_size, img_y - 4 * window_size, window_size):
            yield (i, j)


def remove_white(img):
    img = img.copy()  # make a copy
    main_color = img.mean(axis=(0, 1)).astype(int)
    fill_color = (main_color * 1.2).astype(int)
    white_mask = np.all(img > main_color * 1.4, axis=2)
    img[white_mask, :] = fill_color
    return img


hist_interval = 60


def extract_poi(img, window_size, iterations):
    img = remove_white(img)
    main_color = img.mean(axis=(0, 1)).astype(int)
    hist_ranges = [
        main_color[0] - hist_interval, main_color[0] + hist_interval,
        main_color[1] - hist_interval, main_color[1] + hist_interval,
        main_color[2] - hist_interval, main_color[2] + hist_interval
    ]
    hist_ranges = [min(max(int(x), 0), 255) for x in hist_ranges]

    main_hist = getHist(img, hist_ranges)

    poi = [
        (i, j)
        for i, j in gen_all_segment(img.shape[:2], window_size)
        if cv2.compareHist(getHist(img[i:i + window_size, j:j + window_size, :],
                                   hist_ranges),
                           main_hist, cv2.HISTCMP_CORREL) < 0.2
        ]

    poi = np.array(poi)
    if iterations > 0:
        poi = shrink_poi(poi, iterations)
    return poi


def shrink_poi(poi, iterations=15):
    """
    Remove poi that is far away from the central

    :param poi:
    :param iterations:
    :return:
    """
    while iterations:
        mean = poi.mean(axis=0)
        bias = (poi - mean) / poi.std(axis=0)
        far_neg = np.any(bias < -2, axis=1).reshape((-1, 1))
        far_pos = np.any(bias > 2, axis=1).reshape((-1, 1))
        far = np.any(np.hstack((far_neg, far_pos)), axis=1)
        if not np.any(far):
            break
        poi = poi[~far, :]
        iterations -= 1
    return poi


def gen_roi(img, iterations=15):
    window_size = int(min(img.shape[:2]) / 50)
    poi = extract_poi(img, window_size, iterations)

    center = (poi.mean(axis=0) + window_size / 2).astype(int)
    radius = int(2.2 * np.sqrt(sum(poi.std(axis=0) ** 2)))

    return center[0], center[1], radius


def crop_img(img, **context):
    center_x, center_y, radius = gen_roi(img)
    img_x, img_y = img.shape[:2]
    if 2 * radius > min(img_x, img_y) + 2:
        radius = (min(img_x, img_y) >> 1) + 1

    # move the rectangle into the image
    if center_x < img_x / 2:
        center_x += max(radius - center_x, 0)
    else:
        center_x -= max(center_x + radius - img_x, 0)

    if center_y < img_y / 2:
        center_y += max(radius - center_y, 0)
    else:
        center_y -= max(center_y + radius - img_y, 0)

    img = img[center_x - radius:center_x + radius, center_y - radius:center_y + radius, :]
    return img


def central_crop(img):
    center_x, center_y = img.shape[0] >> 1, img.shape[1] >> 1
    radius = min(center_x, center_y)
    return img[center_x - radius:center_x + radius, center_y - radius, center_y + radius, ...]


def resize_img(img, **context):
    return cv2.resize(img, dsize=context.get('dsize', (300, 300)))


def black_white(img, **context):
    return cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)


def pipeline(*args):
    def execute(img, **context):
        for f in args:
            img = f(img, **context)
        return img

    return execute


bw_small_crop = pipeline(crop_img, black_white, resize_img)
small_crop = pipeline(crop_img, resize_img)
small_central_crop = pipeline(central_crop, resize_img)
bw_small = pipeline(black_white, resize_img)
small = resize_img

if __name__ == '__main__':
    import os
    import random

    cv2.namedWindow('final', cv2.WINDOW_NORMAL)
    cv2.namedWindow('zero_reduced', cv2.WINDOW_NORMAL)
    cv2.namedWindow('white_out', cv2.WINDOW_NORMAL)
    cv2.namedWindow('crop', cv2.WINDOW_NORMAL)

    all_img = [x for x in os.listdir('../data/imgs')
               if x.endswith('.jpg')]
    img_count = len(all_img)

    count = 0
    while 1:
        count += 1
        print(count)
        filename = os.path.join('../data/imgs', all_img[random.randint(0, img_count)])
        # filename = 'data/imgs/w_3399.jpg'
        print(filename)
        img = cv2.imread(filename)
        img_backup = img.copy()
        center_y, center_x, radius = gen_roi(img)  # opencv has reverse y and x
        print(center_y, center_x, radius)

        cv2.resizeWindow('final', int(img.shape[1] / 5), int(img.shape[0] / 5))
        cv2.resizeWindow('zero_reduced', int(img.shape[1] / 5), int(img.shape[0] / 5))
        cv2.resizeWindow('white_out', int(img.shape[1] / 5), int(img.shape[0] / 5))
        cv2.resizeWindow('crop', 300, 300)

        img = cv2.rectangle(img,
                            (center_x - radius, center_y - radius),
                            (center_x + radius, center_y + radius),
                            color=(255, 255, 0), thickness=10)

        cv2.imshow('final', img)
        cv2.imshow('crop', bw_small_crop(img, dsize=(300, 300)))

        cv2.imshow('white_out', remove_white(img))

        img = img_backup
        window_size = int(min(img.shape[:2]) / 50)
        black_patch = np.zeros((window_size, window_size, 3), dtype=img.dtype)
        white_patch = np.ones((window_size, window_size, 3), dtype=img.dtype) * 255
        poi = extract_poi(img, window_size, 0)
        for i, j in poi:
            img[i:i + window_size, j:j + window_size, :] = black_patch
        poi = shrink_poi(poi)
        for i, j in poi:
            img[i:i + window_size, j:j + window_size, :] = white_patch

        cv2.imshow('zero_reduced', img)

        cv2.waitKey()
