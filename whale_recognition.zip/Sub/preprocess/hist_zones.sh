#!/bin/bash
for file in $(ls)
    do
        echo $file
        python hist_zones.py "${file}"
    done
