#!/bin/bash
for file in $(find . -name '*.jpg')
    do
        echo $file
        python resize.py "${file}"
        rm "${file}"
    done
