# coding=utf-8

import numpy as np
import pandas as pd
from data import load_test_data, load_train_data
from pylearn2.models.mlp import (MLP, ConvRectifiedLinear, RectifiedLinear,
                                 Softmax)
from pylearn2.space import Conv2DSpace
from pylearn2.models.maxout import MaxoutConvC01B
from pylearn2.models.autoencoder import DenoisingAutoencoder
from pylearn2.datasets import DenseDesignMatrix
from pylearn2.training_algorithms.learning_rule import AdaDelta
from pylearn2.costs.mlp.dropout import Dropout
from pylearn2.train import Train


def make_model(img_size, labels=447):
    layers = [
        ConvRectifiedLinear(
                output_channels=16,
                kernel_shape=(2, 2),
                pool_shape=(2, 2),
                pool_stride=(1, 1),
                irange=0.01,
                layer_name='conv_1'
        ),
        ConvRectifiedLinear(
                output_channels=32,
                kernel_shape=(2, 2),
                pool_shape=(2, 2),
                pool_stride=(1, 1),
                irange=0.01,
                layer_name='conv_2'
        ),
        ConvRectifiedLinear(
                output_channels=32,
                kernel_shape=(2, 2),
                pool_shape=(2, 2),
                pool_stride=(1, 1),
                irange=0.01,
                layer_name='conv_3'
        ),
        Softmax(n_classes=labels, layer_name='output', irange=0.01)
    ]
    input_space = Conv2DSpace(shape=img_size[1:],
                              num_channels=img_size[0],
                              axes=('b', 'c', 0, 1))

    model = MLP(layers, batch_size=8,
                input_space=input_space)

    return model


def make_trainer(model, validate_data):
    return AdaDelta(decay=0.9)


def make_dataset(X, y):
    return DenseDesignMatrix(topo_view=X, y=y, axes=('b', 'c', 0, 1))


def train_eval(X_train, Y_train, X_test, Y_test, nb_epoch=80):
    model = make_model(X_train[0].shape, Y_train.shape[1])
    train_data = make_dataset(X_train, Y_train)
    validate_data = make_dataset(X_test, Y_test)
    trainer = make_trainer(model, validate_data)

    loop = Train(train_data, model, trainer)
    loop.main_loop()


def predict(path, img_size=(153, 231), tag='regular'):
    X_train, Y_train = load_train_data(path, img_size, tag)

    model = make_model(X_train[0].shape, Y_train.shape[1])
    model = make_trainer(model)
    model.fit(X_train, Y_train, batch_size=64, nb_epoch=16)

    X_test = load_test_data(path, img_size, tag)

    return model.predict(X_test, batch_size=64)


def make_submission(prediction, filename):
    submission = pd.read_csv('data/sample_submission.csv', index_col='Image')
    new_sub = pd.DataFrame(data=prediction, index=submission.index, columns=submission.columns)
    new_sub.to_csv(filename)


def local_validation(img_size, tag, split=0.1):
    def split_buf(buf, train, test):
        test_size = int(split * len(buf_x)) + 1
        train.extend(buf[:-test_size])
        test.extend(buf[-test_size:])

    X_train, Y_train = load_train_data('data/', img_size, tag=tag)
    buf_x, buf_y = [], []
    train_x, train_y = [], []
    test_x, test_y = [], []

    previous_label = np.argmax(Y_train[0, :])
    for x, y in zip(X_train, Y_train):
        current_label = np.argmax(y)
        if current_label != previous_label:
            split_buf(buf_x, train_x, test_x)
            split_buf(buf_y, train_y, test_y)
            previous_label = current_label
            buf_x, buf_y = [], []

        buf_x.append(x)
        buf_y.append(y)

    split_buf(buf_x, train_x, test_x)
    split_buf(buf_y, train_y, test_y)

    X_train, Y_train, X_test, Y_test = [np.array(x)
                                        for x in (train_x, train_y, test_x, test_y)]

    train_eval(X_train, Y_train, X_test, Y_test)


if __name__ == '__main__':
    local_validation((200, 200), 'crop')
    # pred = predict('data/imgs', img_size=(153, 231), tag='whole')
    # make_submission(pred, 'test_sub_2.csv')
