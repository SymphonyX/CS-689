# coding=utf-8

import cv2
import os
import numpy as np
from sklearn.preprocessing.label import LabelBinarizer
import pandas as pd
from preprocess.extract import bw_small_crop, small_crop, small, small_central_crop


def make_train_data(path, img_size, process=None, for_submission=True):
    X_train, Y_train = [], []
    all_labels = []

    for folder in os.listdir(path):
        if os.path.isfile(os.path.join(path, folder)):
            continue
        label = folder
        all_labels.append(label)

        train = read_pictures(os.path.join(path, folder), img_size=img_size,
                              test=False, process=None)
        X_train.extend(train)
        Y_train.extend([label] * len(train))

    if for_submission:
        # if data is for submission, override official submission labels
        submission = pd.read_csv('data/sample_submission.csv', index_col='Image')
        all_labels = list(submission.columns)

    binarizer = LabelBinarizer()
    binarizer.fit(all_labels)

    X_train, Y_train = np.array(X_train), np.array(Y_train)
    Y_train = binarizer.transform(Y_train)
    return X_train, Y_train


def make_train_file_name(path, img_size, tag):
    return 'train_{}_{}_{}.bin'.format(tag, img_size[0], img_size[1])


def persist_train_data(path, img_size=(306, 462), tag='regular',
                       process=None, for_submission=True):
    X_train, Y_train = make_train_data(path, img_size, process=None,
                                       for_submission=for_submission)
    filename = make_train_file_name(path, img_size, tag)

    with open(os.path.join('data', filename), 'wb') as f:
        np.save(f, X_train)
        np.save(f, Y_train)


def load_train_data(path, img_size=(306, 462), tag='regular'):
    filename = make_train_file_name(path, img_size, tag)
    with open(os.path.join('data', filename), 'rb') as f:
        X_train = np.load(f)
        Y_train = np.load(f)

    X_train = np.rollaxis(X_train, 3, 1)
    X_train = X_train.astype('float32')
    X_train /= 255
    return X_train, Y_train


def make_test_data(path, img_size, process=None):
    submission = pd.read_csv('data/sample_submission.csv', index_col='Image')
    test_imgs = list(submission.index)

    X_test = []

    for filename in test_imgs:
        X_test.append(read_picture(path, filename, img_size, process=None))

    X_test = np.array(X_test)

    return X_test


def make_test_file_name(path, img_size, tag):
    return 'test_{}_{}_{}.bin'.format(tag, img_size[0], img_size[1])


def persist_test_data(path, img_size=(306, 462), tag='regular', process=None):
    X_test = make_test_data(path, img_size, process=None)
    filename = make_test_file_name(path, img_size, tag)
    with open(os.path.join('data', filename), 'wb') as f:
        np.save(f, X_test)


def load_test_data(path, img_size=(306, 462), tag='regular'):
    filename = make_test_file_name(path, img_size, tag)
    with open(os.path.join('data', filename), 'rb') as f:
        X_test = np.load(f)

    X_test = np.rollaxis(X_test, 3, 1)
    X_test = X_test.astype('float32')
    X_test /= 255
    return X_test


def read_pictures(path, img_size=(306, 462), test=True, split=0.2, process=None):
    rv = []
    for name in os.listdir(path):
        if not name.endswith('.jpg') or name.startswith('.'):
            continue
        img = read_picture(path, name, img_size, process=None)
        rv.append(img)

    test_size = int(len(rv) * split) + 1
    if test:
        return rv[:-test_size], rv[-test_size:]
    else:
        return rv


def read_picture(path, name, img_size, process=None):
    if process is None:
        process = small
    img = cv2.imread(os.path.join(path, name), flags=1)
    img = process(img, dsize=img_size)
    return img


if __name__ == '__main__':
    persist_train_data('data/imgs', img_size=(153, 231), tag='whole', process=None)
    persist_test_data('data/imgs', img_size=(153, 231), tag='whole', process=None)
