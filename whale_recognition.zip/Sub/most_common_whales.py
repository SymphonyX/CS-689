import os
import pandas as pd
import collections
"""
find the IDs of the 50 most common whales
"""
train = pd.read_csv('../data/train.csv', index_col='Image')
whaleIDs = list(train['whaleID'])
counter = collections.Counter(whaleIDs)
print counter.most_common()[:50]
