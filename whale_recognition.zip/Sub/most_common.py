import pandas as pd
import collections
import csv
import shutil
import os

"""
filtered the 50 most common whales, and save the result to most_common.csv
"""
NUM = 50

train = pd.read_csv('data/train.csv', index_col='Image')
whaleIDs = list(train['whaleID'])
counter = collections.Counter(whaleIDs)
selected = []
for whale in counter.most_common(NUM):
    selected.append(whale[0])

# os.makedirs('data/imgs_face_subset')
# for i in selected:
#     shutil.copytree(os.path.join('data/imgs_face', i),
#                     os.path.join('data/imgs_face_subset', i))

fin = csv.reader(open(r'data/train.csv'), delimiter=',')
filtered = filter(lambda row: row[1] in selected, fin)

src = 'data/train_crop'
dst = 'data/train_crop_%d' % NUM

if not os.path.isdir(dst):
    os.makedirs(dst)

for pic, whale_id in filtered:
    shutil.copy(os.path.join(src, pic), os.path.join(dst, pic))
# csv.writer(open(r'train_10.csv', 'w'), delimiter=',').writerows(filtered)
