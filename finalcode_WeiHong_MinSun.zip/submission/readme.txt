The Methods folder contains functions for different clustering methods.  (Hierarchical clustering and K-Spectral Centroids)
In the hierachical folder, it also contains the function to calculate dynamic tiem warping distance. 

The Evaluation folder contains the implentation of the whole framwork as well as some utility function.
The algotrading.m is the main entrance.

A samll dataset from OKCoin and coinbase are included. For the btc-e dataset, one can download it from this website:http://api.bitcoincharts.com/v1/csv/

Wei Hong and Min Sun
2015/12/19