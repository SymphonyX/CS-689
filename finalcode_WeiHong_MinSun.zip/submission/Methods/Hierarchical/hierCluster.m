function out = hierCluster(interval,clusters)
    Y = pdist(interval, @dtw_wrapper);
    squareform(Y);
    Z = linkage(Y,'complete');
    ind = cluster(Z,'maxclust',20);
    out = hierCentroid(intervals,ind,clusters);
end