function d = dtw_wrapper(x1,x2)
    %x1 is a 1*N dimension vector
    %x2 is a M2*N dimension matrix
    %d is a M2*1 vector, it contains the distance between x1 with each row
    %of x2
    [M,N] = size(x2);
    d = zeros(M,1);
    for i = 1:M
        d(i) = dtw(x1,x2(i,:));
    end
end