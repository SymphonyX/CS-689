% calculate centroid from hierarchical clustering
function out = hierCentroid(intervals,hind,clusters)
    len = size(intervals,2);
    out = zeros(clusters,len);
    for i = 1:clusters
        indx = find(hind == i)
        out(i,:) = mean(intervals(indx,:));
    end
end