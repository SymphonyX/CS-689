function prices = loadprices(filename, interval)
% combine 23370715 time sequences to 1661499 time sequences: 11698 seconds

%% load data 

% the format here is specially for the data structure of our files
% modification may be needed for other data structures
format = '%d%f%f%[^\n\r]';
delimiter = ',';

file = fopen(filename, 'r');
data = textscan(file, format, 'Delimiter', delimiter, 'EmptyValue', NaN, 'ReturnOnError', false);
fclose(file);

time = data{1, 1};
prices = data{1, 2};
volumes = data{1, 3};

%% combine price information within the same time interval

moment = time(1);
sum_price = 0;
sum_volume = 0;
interval_prices = [];

for i = 1:length(time)
    if(moment <= time(i) && time(i) < moment + interval)
        sum_price = sum_price + prices(i) * volumes(i);
        sum_volume = sum_volume + volumes(i);
    else
        sum_price = sum_price / sum_volume; % weighted average of prices
        interval_prices = [interval_prices; sum_price, sum_volume];
        
        moment = time(i); % ignore the intervals without transactions
        sum_price = prices(i) * volumes(i);
        sum_volume = volumes(i);
    end
end


%% update the prices with combined prices and volumes

prices = interval_prices;