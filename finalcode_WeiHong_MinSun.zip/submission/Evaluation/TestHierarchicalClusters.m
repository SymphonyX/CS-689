% load data
importcsv();
assert(length(prices) == length(askVolume));
assert(length(prices) == length(bidVolume));
prices = transpose(prices);
prices = prices(1:2:length(prices)); %turns 5s to 10s steps
askVolume = askVolume(1:2:length(askVolume));
bidVolume = bidVolume(1:2:length(bidVolume));
prices1 = prices(1:20000); 
prices2 = prices(20001:40000);
prices3 = prices(40001:length(prices));
priceDiff = diff(prices);
validIntSize = length(prices1)-750; %valid interval size
interval720s = zeros(validIntSize,720+1);
interval360s = zeros(validIntSize,360+1);
interval180s = zeros(validIntSize,180+1); 
for i = 1:validIntSize   
    interval180s(i,:) = [prices1(i:i+179),priceDiff(i+179)]; 
    interval360s(i,:) = [prices1(i:i+359),priceDiff(i+359)]; 
    interval720s(i,:) = [prices1(i:i+719),priceDiff(i+719)];   
end

%%
%normalize before clustering
interval180s = normalize(interval180s,180);
interval360s = normalize(interval360s,360);
interval720s = normalize(interval720s,720);
%% Clustering
X180s = interval180s(1:2000,:);
Y180s = pdist(X180s,@dtw_wrapper);
squareform(Y180s);
%%

%% Clustering
X360s = interval360s;
Y360s = pdist(X360s,@dtw_wrapper);
squareform(Y360s);
%%

%%
X720s = interval720s;
Y720s = pdist(X720s,@dtw_wrapper);
squareform(Y720s);
%%
Z180s = linkage(Y180s,'complete');
Z360s = linkage(Y360s,'complete');
Z720s = linkage(Y720s,'complete');
%%
figure;
dendrogram(Z180s,0);
%%
hind180s = cluster(Z180s,'maxclust',20);
hind360s = cluster(Z360s,'maxclust',20);
hind720s = cluster(Z720s,'maxclust',20);
%%
hier_cluster180s = hierCentroid(interval180s, hind180s, 20);
hier_cluster360s = hierCentroid(interval360s, hind360s, 20);
hier_cluster720s = hierCentroid(interval720s, hind720s, 20);
%%
hier_cluster360s = normalize(hier_cluster360s,360);
hier_cluster720s = normalize(hier_cluster720s,720);
%% use clusters learned from hierarchical clustering with dtw to trade on the whole time series of OKCoin
% load clusters


% load time series
importcsv();
assert(length(prices) == length(askVolume));
assert(length(prices) == length(bidVolume));
prices = transpose(prices);
prices = prices(1:6:length(prices)); %turns 5s to 30s steps
plen = length(prices);
prices1 = prices(1:plen/2);
prices2 = prices(plen/2 + 1 : plen);
askVolume = askVolume(1:6:length(askVolume));
bidVolume = bidVolume(1:6:length(bidVolume));
% regression
%%
c180s = hier_cluster180s;
c360s = hier_cluster360s;
c720s = hier_cluster720s;
regressorX = zeros(length(prices2)-750-1,4);
regressorY = zeros(1,length(prices2)-750-1);

for i= 750:length(prices2)-1
    price180 = prices2(i-179:i);      
    price360 = prices2(i-359:i);      
    price720 = prices2(i-719:i);
    
%#average price change dp_j is given by bayesian regression    
    dp1 = bayesian(price180, c180s,c360s,c720s);
    dp2 = bayesian(price360, c180s,c360s,c720s); 
    dp3 = bayesian(price720, c180s,c360s,c720s);
    
    r = (bidVolume(i)-askVolume(i))/(bidVolume(i)+askVolume(i)); 
    
    regressorX(i-749,:) = [dp1,dp2,dp3,r];
    regressorY(i-749) = prices2(i+1)-prices2(i);   
end

%last parameter is regularization gamma, need to find a good value TODO
[theta, theta0] = train_regressor(regressorX, transpose(regressorY), 1);
disp('finished regression, ready to trade');

m = length(prices1) + length(prices2); %we want to take bid/ask data from right index


%start trading with last list of prices
%%
% trading
tic
out = Testbrtrade(prices3, c180s,c360s,c720s,theta,theta0,bidVolume(m:end),askVolume(m:end));
toc
%%
% ploting
signal = out{1};
ret = out{3};
p = out{4};
figure;
plot(signal*1000,'b');
hold on;
plot(p-p(1),'r');
hold off;
figure;
plot(ret,'b');
hold on;
plot(p - p(1),'r');
hold off;