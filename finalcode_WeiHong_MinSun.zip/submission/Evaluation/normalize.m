function out = normalize(a, len) 
out = a;
out(:,1:len) = bsxfun(@minus,a(:,1:len),mean(a(:,1:len),2));
out(:,1:len) = bsxfun(@rdivide,out(:,1:len),std(out(:,1:len),1,2));
end