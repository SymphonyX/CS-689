function score = evaluatepatterns(patterns, prices, mode)

N = length(prices);
M = length(patterns);
S = size(patterns, 1);
score = zeros(2, S); % the first row counts right predictions, the second counts wrong predictions

for i = 1:S
    patterns(i, 1:M-1) = zscore(patterns(i, 1:M-1));
end

if(nargin == 2)
    mode = 'default';
end

if(strcmp(mode, 'default'))
    
    for i = 1:N-M
        patternIndex = patternMatching(prices(i:i+M-1), patterns);
        if((prices(i+M)-prices(i+M-1)) * patterns(patternIndex, M) > 0)
            score(1, patternIndex) = score(1, patternIndex) + 1;
        else
            score(2, patternIndex) = score(2, patternIndex) + 1;
        end
    end
    
else
    
    if(strcmp(mode, 'bayesian'))
        for i = 1:N-M
            if(bayesian(prices(i:i+M-1), patterns) * (prices(i+M)-prices(i+M-1)) > 0)
                score(1, 1) = score(1,1) + 1;
            else
                score(2, 1) = score(2,1) + 1;
            end
        end
    end
    
end

end