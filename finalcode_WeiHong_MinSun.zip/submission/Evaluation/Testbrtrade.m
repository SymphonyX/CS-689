function out = Testbrtrade(prices, c180s,c360s,c720s,theta,theta0,bidVolume,askVolume,threshold)
    out = cell(4,1);
    signal = []; % trading signal
    pos = []; % current position
    ret = []; % current return (cash + value of bitcoins in hold )
    p = []; % price of bitcoin
    position = 0;
    bank = 0;
    error = 0; %current error metric is sum(abs(error))/time interval = ~.9
    
    for t = 750:length(prices)-1    
        price180 = normalize(prices(t-179:t),180);      
        price360 = normalize(prices(t-359:t),360);      
        price720 = normalize(prices(t-719:t),720);

%#average price change dp_j is given by bayesian regression    
        dp1 = bayesian(price180,c180s,c360s,c720s);
        dp2 = bayesian(price360,c180s,c360s,c720s);
        dp3 = bayesian(price720,c180s,c360s,c720s);

        r = (bidVolume(t)-askVolume(t))/(bidVolume(t)+askVolume(t));
        
        dp = theta0 +  theta(1)*dp1 + theta(2)*dp2 + theta(3)*dp3 + theta(4)*r;
        signal = [signal, dp];
        error = error + abs(prices(t+1)-(prices(t)+dp));      
        pos = [pos, position];
        ret = [ret, bank + position*prices(t)];
        p = [p, prices(t)];
        %#BUY
        if (dp > threshold && position == 0)
            position = position + 1;
            bank = bank - prices(t);
            disp('buying');
        end 
        %#SELL
        if (dp < -threshold && position > 0)
            position = position -1;
            bank = bank + prices(t);
            disp('selling');
        end
    end
    
    error = error/(length(prices)-1);
    %settle at end
    if (position == 1)
        bank = bank + prices(length(prices));
    end
    if (position == -1)
        bank = bank - prices(length(prices));
    end
    ret = [ret,bank];
    out{1,:} = signal;
    out{2,:} = pos;
    out{3,:} = ret;
    out{4,:} = p;
  end
