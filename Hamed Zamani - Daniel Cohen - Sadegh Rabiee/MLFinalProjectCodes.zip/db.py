import sys,os,json,random
sys.path.append(os.path.join(os.path.dirname(__file__), 'config'))
import config
from extractor import Extractor

class Singleton:
  def __init__(self, klass):
    self.klass = klass
    self.instance = None
  def __call__(self, *args, **kwds):
    if self.instance == None:
      self.instance = self.klass(*args, **kwds)
    return self.instance

@Singleton
class DB:
	datasets = config.config["DATASET"]["list"].split(',')
	users = {}
	def __init__(self):
		print("init")
		self.dataset = {k:{} for k in self.datasets}
		#self.load_data()		

	def extract_data(self):
		for dataset in config.config["DATASET"]["list"].split(','):
			Extractor.extract_dataset(dataset)

	def load_data(self):
		print("loading data")
		for dataset in config.config["DATASET"]["list"].split(','):
			with open(config.config["OUT"][dataset]) as json_data:
				self.users[dataset] = json.load(json_data)
		print("done")

	# def organize_data(self):
	# 	random_seed = 0
	# 	shuffles = 30
	# 	folders = ["features", "labels", "predictions", "evaluations"]
	# 	for i in range(1,shuffles+1):
	# 		if not os.path.exists("data/shuffle"+str(i)):
	# 			os.makedirs("data/shuffle"+str(i))
	# 		for folder in folders:
	# 			if not os.path.exists(os.path.join("data","shuffle"+str(i),folder)):
	# 				os.makedirs(os.path.join("data","shuffle"+str(i),folder))
	# 			if not folder == 'evaluations':
	# 				for dataset in self.datasets:
	# 					if not os.path.exists(os.path.join("data","shuffle"+str(i),folder,dataset)):
	# 						os.makedirs(os.path.join("data","shuffle"+str(i),folder,dataset))
	# 	m = min(map(lambda x: len(self.users[x].keys()), self.datasets))
	# 	for i in range(1,shuffles+1):	
	# 		random_seed += 1
	# 		random.seed(random_seed)
	# 		for dataset in self.datasets:
	# 			shuffled_users = random.shuffle(self.users[dataset].keys())
	# 			selected_users = shuffled_users[0:m-1]
	# 			train_users = selected_users[:len(selected_users)/2]
	# 			test_users = selected_users[len(selected_users)/2:]
	# 			for j in range(1:11):
	# 				for train_user in train_users[:len(train_users)*j/10]
	# 					for tweet in self.users[dataset][train_user]:
	# 						file.write(extract_feature(tweet))
	# 						file.write(engagement)
	# 			for test_user in test_users:
	# 				for tweet in self.users[dataset][test_user]:
	# 					file.write(extract_feature(tweet))
	# 					file.write(engagement)