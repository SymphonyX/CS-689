import db,extractor,os, sys
sys.path.append(os.path.join(os.path.dirname(__file__), 'lib/utils'))
sys.path.append(os.path.join(os.path.dirname(__file__), 'lib/classification'))
sys.path.append(os.path.join(os.path.dirname(__file__), 'lib/regression'))
import loader
from MA import MA
from sgd import SGD
from lasso import LassoRegression
from ridge import RidgeRegression
from LinearSVC import LinSVC
from ndcg import *
from multiprocessing import Pool
from multiprocessing import Process
import helper
from measures import *
def write_single_in_file(item, f):
	f.write(str(item))
	f.write("\n")

def write_in_file(arr, f):
	for i,el in enumerate(arr):
		f.write(str(el))
		f.write("\n")

def create_folders():
	for shuffle in range(1,31):
		if not os.path.exists("data/common/shuffle"+str(shuffle)):
			os.makedirs("data/common/shuffle"+str(shuffle))

class MultiPub:
	def pooling_classification(self):
		create_folders()

		for shuffle in range(1,31):
			pos, neg, gm, conm = [], [], [], []

			for fold in range(1,11):
				x_train, y_train = loader.load_pooling_train(db.DB().datasets, shuffle, fold)

				estimator = MA.train(x_train, y_train, "data/common/shuffle"+str(shuffle)+"/PoolingLogisticRegression_params_fold_"+str(fold)+".dat")

				for ds in db.DB().datasets:
					print("#############  dataset:  "+str(ds)+" shuffle: "+str(shuffle)+" fold: " +str(fold) + " ######################")
					x_test, y_test = loader.load_pooling_test(ds, shuffle, fold)

					p, n, g, c = MA.test(x_test, y_test, loader.get_prediction_path("PoolingLogisticRegression", ds, shuffle, fold), estimator)

					pos_file = open(os.path.join("data", ds, "shuffle"+str(shuffle), "evaluations", "PoolingLogisticRegression_pos.dat"),"a")
					neg_file = open(os.path.join("data", ds, "shuffle"+str(shuffle), "evaluations", "PoolingLogisticRegression_neg.dat"),"a")
					gm_file = open(os.path.join("data", ds, "shuffle"+str(shuffle), "evaluations", "PoolingLogisticRegression_gm.dat"),"a")
					conm_file = open(os.path.join("data", ds, "shuffle"+str(shuffle), "evaluations", "PoolingLogisticRegression_ConfusionMatrix.dat"),"a")

					write_single_in_file(p, pos_file)
					write_single_in_file(n, neg_file)
					write_single_in_file(g, gm_file)
					write_single_in_file(c, conm_file)

					pos_file.close()
					neg_file.close()
					gm_file.close()
					conm_file.close()


	def binary_classification(self, key, disabled_features = []):
		#for ds in db.DB().datasets:
		for ds in ["goodreads"]:
			print("LOADING dataset")

			ids = {}
			lines = []
			for line in open("../crawl/dataset/goodreads/reads.dat"):
				lines.append(line)
				splitted = line.split(',')
				if('_' in splitted[2]):
					ids[(' '.join(splitted[2].split('.')[1].split('_'))).lower()] = splitted[2].split('.')[0]
				elif('-' in splitted[2]):
					ids[(' '.join(splitted[2].split('-')[1:])).lower()] = splitted[2].split('-')[0]
				elif('.' in splitted[2]):
					ids[splitted[2].split('.')[0].lower()] = splitted[2].split('.')[1]
			tweets, items = helper.load_dataset(ds, ids, lines)

			print("LOADING done!")
			for shuffle in range(1,31):
				pos_file = open(os.path.join("data", ds, "shuffle"+str(shuffle), "evaluations", key+"_pos.dat"),"w")
				neg_file = open(os.path.join("data", ds, "shuffle"+str(shuffle), "evaluations", key+"_neg.dat"),"w")
				bacc_file = open(os.path.join("data", ds, "shuffle"+str(shuffle), "evaluations", key+".bacc"),"w")
				conm_file = open(os.path.join("data", ds, "shuffle"+str(shuffle), "evaluations", key+"_ConfusionMatrix.dat"),"w")
				f_measure_file = open(os.path.join("data", ds, "shuffle"+str(shuffle), "evaluations", key+".f_measure"),"w")
				pos, neg, bacc, conm = [], [], [], []

				for fold in range(1,11):
					print("#############  dataset:  "+str(ds)+" shuffle: "+str(shuffle)+" fold: " +str(fold) + " ######################")
					x_train, y_train, x_test, y_test = loader.load_scikit_data(ds,shuffle,fold, True, tweets, items)

					f = open("/tmp/test.dat","w")
					write_in_file(y_test, f)
					f.close()
					# new_x_train = []
					# new_x_test = []
					#
					# def refill(new_arr, old_arr, disabled):
					# 	for x_vector in old_arr:
					# 		new_v = []
					# 		for i in range(0, len(x_vector)):
					# 			if not i in disabled:
					# 				new_v.append(x_vector[i])
					# 		new_arr.append(new_v)
					#
					# refill(new_x_train, x_train, disabled_features)
					# refill(new_x_test, x_test, disabled_features)

					#p, n, b, c = MA.apply(new_x_train, y_train, new_x_test, y_test, loader.get_prediction_path(key, ds, shuffle, fold), loader.get_params_path(key, ds, shuffle, fold))
					p, n, b, c = LinSVC.apply(x_train, y_train, x_test, y_test, loader.get_prediction_path(key, ds, shuffle, fold), loader.get_params_path(key, ds, shuffle, fold))

					prediction_path = loader.get_prediction_path(key, ds, shuffle, fold)
					test_path = "/tmp/test.dat"
					measure = Measure(test_path, prediction_path, True)
					f_measure_file.write(str(measure.f_measure()))
					if(fold != 10):
						f_measure_file.write("\n")

					pos.append(str(p))
					neg.append(str(n))
					bacc.append(str(b))
					conm.append(str(c))

				write_in_file(pos, pos_file)
				write_in_file(neg, neg_file)
				write_in_file(bacc, bacc_file)
				write_in_file(conm, conm_file)

				pos_file.close()
				neg_file.close()
				bacc_file.close()
				conm_file.close()
				f_measure_file.close()

	def apply_regression(self, key):
		for ds in db.DB().datasets:
		#for ds in ["pandora", "youtube"]:
		#for ds in ["youtube"]:
			#for shuffle in range(12 if ds == "pandora" else 1,31):
			for shuffle in range(1,31):
				ndcg_file = open(os.path.join("data", ds, "shuffle"+str(shuffle), "evaluations", key+".ndcg"),"w")
				test_path = os.path.join("data",ds,"shuffle"+str(shuffle),"features","test.dat")
				ndcg = []
				for fold in range(1,11):
				#for fold in range(10,11):
					print("#############  dataset:  "+str(ds)+" shuffle: "+str(shuffle)+" fold: " +str(fold) + " ######################")
					#ndcg_path = os.path.join("data", ds, "shuffle"+str(shuffle), "evaluations", key+"_NDCG.dat")
					x_train, y_train, x_test, y_test = loader.load_scikit_data(ds,shuffle,fold)
					#SGD.apply(x_train, y_train, x_test, y_test, loader.get_prediction_path(key, ds, shuffle, fold), loader.get_params_path(key, ds, shuffle, fold))
					LassoRegression.apply(x_train, y_train, x_test, y_test, loader.get_prediction_path(key, ds, shuffle, fold), loader.get_params_path(key, ds, shuffle, fold))
					ndcg.append(get_whole_ndcg(test_path, loader.get_prediction_path(key, ds, shuffle, fold)))
				write_in_file(ndcg, ndcg_file)
				ndcg_file.close()
				print(">>> DONE:  <<<")

	def pooling_regression(self, key):
		for shuffle in range(23,31):
			for fold in range(1,11):
				x_train, y_train = loader.load_pooling_train(db.DB().datasets, shuffle, fold)
				estimator = RidgeRegression.train(x_train, y_train, "/dev/null")

				for ds in db.DB().datasets:
					print("#############  dataset:  "+str(ds)+" shuffle: "+str(shuffle)+" fold: " +str(fold) + " ######################")
					x_test, y_test = loader.load_pooling_test(ds, shuffle, fold)
					ndcg_file = open(os.path.join("data", ds, "shuffle"+str(shuffle), "evaluations", key+".ndcg"),"a")
					test_path = os.path.join("data",ds,"shuffle"+str(shuffle),"features","test.dat")
					prediction_path = loader.get_prediction_path(key, ds, shuffle, fold)

					RidgeRegression.test(x_test, y_test, prediction_path, estimator)

					ndcg_value = get_whole_ndcg(test_path, prediction_path)
					print("######## ndcg_value:  ", ndcg_value)
					ndcg_file.write(str(ndcg_value)+"\n")
					ndcg_file.close()


	def apply_regression_on_pairs(self):
		results = {}
		datasets = ["imdb", "youtube", "pandora", "goodreads"]
		for ds1 in datasets:
			results[ds1] = {}
			for ds2 in datasets:
				results[ds1][ds2] = []

		for shuffle in range(1,31):
			for ds1 in datasets:
				x_train, y_train = loader.load_scikit_train(ds1, shuffle, 10)
				estimator = RidgeRegression.train(x_train, y_train, "/dev/null")

				for ds2 in datasets:
					if(ds1 != ds2):
						continue
					print("train on ", ds1, " test on ", ds2, " shuffle ", shuffle)
					test_path = os.path.join("data",ds2,"shuffle"+str(shuffle),"features","test.dat")
					x_test, y_test = loader.load_scikit_test(ds2, shuffle, 10)
					RidgeRegression.test(x_test, y_test, "/tmp/pred.dat", estimator)
					results[ds1][ds2].append(get_whole_ndcg(test_path, "/tmp/pred.dat"))
					print("result:  ", results[ds1][ds2])

		print("results:   ", results)
		for ds1 in datasets:
			for ds2 in datasets:
				if(ds1 != ds2):
					continue
				print("train on ", ds1, " test on ", ds2, " result:  ", np.mean(results[ds1][ds2]))

	def apply_classification_on_pairs(self):
		results = {}
		datasets = ["imdb", "youtube", "pandora", "goodreads"]
		for ds1 in datasets:
			results[ds1] = {}
			for ds2 in datasets:
				results[ds1][ds2] = []

		for shuffle in range(1,31):
			for ds1 in datasets:
				x_train, y_train = loader.load_scikit_train(ds1, shuffle, 10)
				estimator = LinSVC.train(x_train, y_train, "/dev/null")

				for ds2 in datasets:
					if(ds1 == ds2):
						continue
					print("train on ", ds1, " test on ", ds2, " shuffle ", shuffle)
					test_path = os.path.join("data",ds2,"shuffle"+str(shuffle),"features","test.dat")
					x_test, y_test = loader.load_scikit_test(ds2, shuffle, 10)
					p, n, b, c = LinSVC.test(x_test, y_test, "/tmp/pred.dat", estimator)
					results[ds1][ds2].append(b)
					print("balanced accuracy result:  ", b)

		print("results:   ", results)
		for ds1 in datasets:
			for ds2 in datasets:
				if(ds1 == ds2):
					continue
				print("train on ", ds1, " test on ", ds2, " result:  ", np.mean(results[ds1][ds2]))
