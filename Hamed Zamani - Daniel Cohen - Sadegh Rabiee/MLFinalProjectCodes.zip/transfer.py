import os
import shutil
import glob

def transfer(pattern, destination):
	for dataset in ["goodreads", "imdb", "pandora", "youtube"]:
		os.makedirs(os.path.join(destination, dataset))
		for shuffle in range(1,31):
			os.makedirs(os.path.join(destination, dataset, "shuffle"+str(shuffle)))
			os.makedirs(os.path.join(destination, dataset, "shuffle"+str(shuffle), "predictions"))
			os.makedirs(os.path.join(destination, dataset, "shuffle"+str(shuffle), "evaluations"))

			for f in glob.glob(os.path.join("data", dataset, "shuffle"+str(shuffle), "predictions", pattern+"*")):
				shutil.copy2(f, os.path.join(destination, dataset, "shuffle"+str(shuffle), "predictions"))
			for f in glob.glob(os.path.join("data", dataset, "shuffle"+str(shuffle), "evaluations", pattern+"*")):
				shutil.copy2(f, os.path.join(destination, dataset, "shuffle"+str(shuffle), "evaluations"))

try:
	shutil.rmtree('/tmp/data')
	os.remove("/tmp/data.zip")
except OSError:
	None
os.makedirs("/tmp/data")
transfer("Logistic", "/tmp/data")
shutil.make_archive("/tmp/data", 'zip', "/tmp/data")

