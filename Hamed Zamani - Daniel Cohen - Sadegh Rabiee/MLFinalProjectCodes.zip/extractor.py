from datetime import datetime
import sys,os,json,re, glob,base64
sys.path.append(os.path.join(os.path.dirname(__file__), 'config'))
import config
from collections import defaultdict
import db,random

ids = {}
for line in open(os.path.join(config.config["DATASET"]["goodreads"],"reads.dat")):
	splitted = line.split(',')
	if('_' in splitted[2]):
		ids[(' '.join(splitted[2].split('.')[1].split('_'))).lower()] = splitted[2].split('.')[0]
	elif('-' in splitted[2]):
		ids[(' '.join(splitted[2].split('-')[1:])).lower()] = splitted[2].split('-')[0]
	elif('.' in splitted[2]):
		ids[splitted[2].split('.')[0].lower()] = splitted[2].split('.')[1]

def get_imdb_rating(text):
	pattern = '([0-9]+)/10'
	p = re.compile(pattern,re.M | re.I)
	matches = p.findall(text)
	if len(matches) != 0:
		rating = matches[0]
	else:
		rating = ''
	return rating

def get_id(link,dataset,text):
	if dataset == 'imdb':
    #http://www.imdb.com/title/tt0970866
		pattern = '.*?/tt([0-9]*)/*$'
		p = re.compile(pattern,re.M | re.I)
		matches = p.findall(link)
		if len(matches) > 0:
			return matches[0]
		else:
			return -1
	elif dataset == 'pandora':
		pattern = 'I.*listening to (.*) by (.*) on'
		m = re.search(pattern,text)
		if m == None:
			return -1
		songtitle = m.group(1).replace('"', '')
		return str(base64.b64encode(str.encode(songtitle)))[2:-1]
	elif dataset == 'youtube':
		pattern = 'youtu.be/(.*)\?a$'
		p = re.compile(pattern,re.M | re.I)
		matches = p.findall(link)
		if len(matches) > 0:
			return matches[0]
		else:
			return -1
	elif dataset == 'goodreads':
		pattern = 'to (.*) by (.*)'
		try:
			title = re.search(pattern,text).group(1)
		except AttributeError:
			return -1

		try:
			if("..." in title):
				for k in ids.keys():
					if(title.replace("...","").strip().lower() in k):
						return ids[k]
			else:
				return ids[title.lower()]
		except KeyError:
			return -1

def get_week_offset(day):
	if(day == 'Sat'):
		return 0
	elif(day == 'Sun'):
		return 1
	elif(day == 'Mon'):
		return 2
	elif(day == 'Tue'):
		return 3
	elif(day == 'Wed'):
		return 4
	elif(day == 'Thu'):
		return 5
	elif(day == 'Fri'):
		return 6
	else:
		print(day)
		print("fuck!!!!!11")

def get_movie_tweets(all_data, item_id):
	result = []
	for user,array in all_data.items():
		for tweet in array:
			if(tweet['item_id'] == item_id):
				result.append(tweet)
	return result

class Extractor:
	@classmethod
	def load_json(self, json_file,dataset):
		main_hash = defaultdict(list)
		with open(json_file) as json_data:
			data = json.load(json_data)
			for tweet in data:
				user_hash = {}
				item_hash = {}
				if len(tweet['entities']['urls']) == 0:
					continue
				user_hash['item_id'] = get_id(tweet['entities']['urls'][0]['expanded_url'],dataset,tweet['text'])
				if(user_hash['item_id'] == -1):
					continue
				user_hash['tweet_id'] = tweet['id']
				user_hash['retweet_count'] = tweet['retweet_count']
				user_hash['favorite_count'] = tweet['favorite_count']
				user_hash['engagement'] = tweet['retweet_count'] + tweet['favorite_count']
				user_hash['mention_count'] = len(tweet['entities']['user_mentions'])
				user_hash['hashtag_count'] = len(tweet['entities']['hashtags'])
				time = datetime.strptime(tweet['created_at'].replace(' +0000',''), '%a %b %d %H:%M:%S %Y')
				user_hash['tweet_age'] = int((datetime.now() - time).total_seconds())
				user_hash['followers_count'] = tweet['user']['followers_count']
				user_hash['friends_count'] = tweet['user']['friends_count']
				user_hash['verified'] = tweet['user']['verified']
				user_hash['lang'] = tweet['user']['lang']
				user_hash['tweet_lang'] = tweet['lang']
				user_hash['statuses_count'] = tweet['user']['statuses_count']
				user_hash['favourites_count'] = tweet['user']['favourites_count']
				user_hash['listed_count'] = tweet['user']['listed_count']
				time = datetime.strptime(tweet['user']['created_at'].replace(' +0000',''), '%a %b %d %H:%M:%S %Y')
				user_hash['user_age'] = int((datetime.now() - time).total_seconds())
				user_hash['tweet_created_at'] = tweet['created_at']
				user_hash['user_created_at'] = tweet['user']['created_at']
				user_hash['location'] = tweet['user']['location']
				user_hash['user_id'] = tweet['user']['id']
				item_hash['item_id'] = user_hash['item_id']
				item_hash['user_id'] = user_hash['user_id']
				item_hash['tweet_id'] = user_hash['tweet_id']
				item_hash['retweet_count'] = user_hash['retweet_count']
				item_hash['favorite_count'] = user_hash['favorite_count']
				item_hash['engagement'] = user_hash['engagement']
				item_hash['age'] = user_hash['tweet_created_at']
				item_hash['created_at'] = user_hash['tweet_created_at']
				item_hash['lang'] = user_hash['tweet_lang']

				main_hash[user_hash['user_id']].append(user_hash)
		return main_hash

	@classmethod
	def get_selectional_item_data(self,custom_users): # extract items hash from a set of tweets and users
		h = defaultdict(list)
		r_h = defaultdict(list)
		for user_id, array in custom_users.items():
			for tweet in array:
				r_h = {}
				r_h['item_id'] = tweet['item_id']
				r_h['user_id'] = tweet['user_id']
				r_h['tweet_id'] = tweet['tweet_id']
				r_h['retweet_count'] = tweet['retweet_count']
				r_h['favorites_count'] = tweet['favorite_count']
				r_h['engagement'] = tweet['engagement']
				r_h['age'] = tweet['tweet_age']
				r_h['created_at'] = tweet['tweet_created_at']
				r_h['lang'] = tweet['tweet_lang']
				h[r_h['item_id']].append(r_h)

		result = {}
		for item_id, array in h.items():
			sorted_tweets = sorted(array, key=lambda k: k["age"])
			for i,tweet in enumerate(sorted_tweets):
				tweet["ratings_count"] = i + 1
				# tweet["average_of_its_engagements"] = sum(map(lambda x: x["engagement"], sorted_tweets[0:i+1])) / (i+1)
				# tweet["average_of_its_retweets"] = sum(map(lambda x: x["retweet_count"], sorted_tweets[0:i+1])) / (i+1)
				# tweet["average_of_its_favorites"] = sum(map(lambda x: x["favorite_count"], sorted_tweets[0:i+1])) / (i+1)
			result[item_id] = sorted_tweets
		return result
		# return h

	@classmethod
	def handle_users(self,users,dataset):
		random_seed = 0
		shuffles = 30
		folders = ["features", "labels", "predictions", "evaluations"]

		for ds in db.DB().datasets:
			if not os.path.exists(os.path.join("data", ds)): #/data/imdb
				os.makedirs(os.path.join("data", ds))
			for i in range(1,shuffles+1):
				if not os.path.exists(os.path.join("data",ds,"shuffle"+str(i))):
					os.makedirs(os.path.join("data",ds,"shuffle"+str(i)))
				for folder in folders:
					if not os.path.exists(os.path.join("data",ds,"shuffle"+str(i),folder)):
						os.makedirs(os.path.join("data",ds,"shuffle"+str(i),folder))

		#m = min(map(lambda x: len(db.DB().users[x].keys()), db.DB().datasets))
		min_tweets = 65000

		for i in range(1,shuffles+1):
			random_seed += 1
			random.seed(random_seed)
			shuffled_users = list(users.keys())
			random.shuffle(shuffled_users)

			m,c = 0,0
			for key in shuffled_users:
				c += len(users[key])
				m += 1
				if(c >= min_tweets):
					break
			print("number of users for shuffle ", i , " is ", m)
			print("number of instances for shuffle ", i , " is ", c)

			selected_users = shuffled_users[0:m-1]
			train_users = selected_users[:int(len(selected_users)/2)]
			test_users = selected_users[int(len(selected_users)/2):]
			for j in range(1,11):
				custom_tweets = {key: users[key] for key in train_users[:int(len(train_users)*j/10)]}
				items_data = self.get_selectional_item_data(custom_tweets)
				self.dump_general_json(custom_tweets, items_data, dataset, i, "train", j)
				self.dump_features_file(custom_tweets, items_data, dataset, i, "train", j)

			custom_tweets = {key: users[key] for key in test_users}
			items_data = self.get_selectional_item_data(custom_tweets)
			self.dump_general_json(custom_tweets, items_data, dataset, i, "test")
			self.dump_features_file(custom_tweets, items_data, dataset, i, "test")

	@classmethod
	def get_features(self,tweet, items_data): # get features of hash. we need a items_data source. we normalize later
		features = {}
		features[1] = tweet['ratings_count']
		features[2] = tweet['followers_count']
		features[3] = tweet['friends_count']
		features[4] = tweet['mention_count']
		features[5] = tweet['hashtag_count']

		item_tweet = {}
		for t in items_data[tweet['item_id']]:
			if(t['tweet_id'] == tweet['tweet_id']):
				item_tweet = t
				break

		features[7] = item_tweet['ratings_count']
		features[8] = tweet['statuses_count']
		features[9] = tweet['favourites_count']
		features[10] = tweet['listed_count']
		features[11] = tweet['user_age']
		features[12] = tweet['statuses_count'] / float(tweet['user_age']+1)
		features[13] = tweet['followers_count'] / float(tweet['user_age']+1)
		features[14] = tweet['friends_count'] / float(tweet['user_age']+1)
		features[15] = tweet['favourites_count'] / float(tweet['user_age']+1)
		features[16] = tweet['followers_count'] - tweet['friends_count']
		features[17] = tweet['statuses_count'] / float(tweet['followers_count']+1)
		features[18] = int(tweet['tweet_created_at'].split()[3].split(':')[0])
		features[19] = self.get_hour_label(int(tweet['tweet_created_at'].split()[3].split(':')[0]))
		offset = get_week_offset(tweet['tweet_created_at'].split()[0])
		features[20] = offset
		features[21] = 1 if (offset in [0,1,"0","1"]) else 0
		features[22] = 1 if (tweet['lang'] == item_tweet['lang']) else 0
		features[23] = 1 if (item_tweet['lang'] == "en") else 0
		return features

	@classmethod
	def get_hour_label(self,hour): # get thel label of an hour
		if hour in range(4,13):
			return 0
		if(hour in range(13,16)):
			return 1
		if(hour in range(16,21)):
			return 2
		if(hour in range(21,25)):
			return 3
		if(hour in range(0,4)):
			return 4

	@classmethod
	def dump_features_file(self, custom_tweets, items_data, dataset, shuffle, label, j = -1): #normalize fearures and dumps them to a fucking file

		if label == "train":
			f = open(os.path.join("data",dataset,"shuffle"+str(shuffle),"features","train_"+str(j)+".dat"),'w')
			f_r = open(os.path.join("data",dataset,"shuffle"+str(shuffle),"features","ranker_train_"+str(j)+".dat"),'w')
			s = open(os.path.join("data",dataset,"shuffle"+str(shuffle),"labels","train_"+str(j)+".dat"),'w')

		else:
			f = open(os.path.join("data",dataset,"shuffle"+str(shuffle),"features","test.dat"),'w')
			f_r = open(os.path.join("data",dataset,"shuffle"+str(shuffle),"features","ranker_test.dat"),'w')
			s = open(os.path.join("data",dataset,"shuffle"+str(shuffle),"labels","test.dat"),'w')

		max_features = {}
		min_features = {}
		result = defaultdict(list)

		for user_id,array in custom_tweets.items():
			for tweet in array:
				featured_tweet = self.get_features(tweet, items_data)
				for key,value in featured_tweet.items():
					if(key in max_features.keys()):
						if(max_features[key] < value):
							max_features[key] = value
					else:
						max_features[key] = value
					if(key in min_features.keys()):
						if(min_features[key] > value):
							min_features[key] = value
					else:
						min_features[key] = value

		# if(label == "test"):
		# 	for user_id in sorted(custom_tweets.keys())[::-1]:
		# 		sorted_tweets = sorted(custom_tweets[user_id], key = lambda x : (-1 * float(x["engagement"]), -1*x["tweet_id"]))
		# 		for tweet in sorted_tweets:
		# 			s.write(str(user_id)+","+str(tweet["tweet_id"])+","+str(tweet["engagement"])+"\n")

		i = 0
		for user_id,array in custom_tweets.items():
			i += 1
			sorted_tweets = list(set(sorted(map(lambda x: x["engagement"], array))))
			# if(label == "test"):
			# 	for tweet in sorted_tweets:
			# 		s.write(str(tweet['user_id'])+','+str(tweet['tweet_id'])+','+str(tweet['engagement']))

			dist_rank = len(sorted_tweets) - 5
			for j,tweet in enumerate(array):
				line = str(user_id)+","+str(tweet["tweet_id"])+","+str(tweet["engagement"])+","
				line_r = ""
				if label == "train":
					rank = (sorted_tweets.index(tweet["engagement"]) + 1)
					if(len(sorted_tweets) > 5):
						rank -= dist_rank
					if rank <= 0:
						rank = 1
				else:
					rank = j+1

				line_r += str(rank) + " qid:" + str(i)
				#line +=

				featured_tweet = self.get_features(tweet, items_data)
				normalized_tweet = {}
				for key,value in featured_tweet.items():
					#if(min_features[key] == max_features[key]):
						#print("fuck! key: " + str(key) + " value:  "+str(min_features[key]))
					line += str((value - min_features[key]) / float((max_features[key] - min_features[key])+0.00001))+","
					line_r += " "+str(key)+":"+str((value - min_features[key]) / float((max_features[key] - min_features[key])+0.00001))

				line = line[:-1]
				line += "\n"
				line_r += " # "+str(user_id)+" "+str(tweet["tweet_id"])+" "+str(tweet["engagement"])+"\n"
				f.write(line)
				f_r.write(line_r)
				s.write(str(tweet['engagement'])+"\n")

		f.close()
		s.close()
		f_r.close()

	@classmethod
	def dump_general_json(self,custom_tweets, items_data, dataset, shuffle, label, j = -1):
		print(">>> dumping general json files")
		print(">>> dataset: ", dataset)
		print(">>> shuffle: ", shuffle)
		print(">>> label: ", label)
		print(">>> j: ", j)
		print(">>> tweet keys length: ", len(custom_tweets.keys()))
		print(">>> items keys length: ", len(items_data.keys()))

		with open(os.path.join("data",dataset,"shuffle"+str(shuffle),label+"_"+"tweets" + (("_"+str(j)) if j != -1 else "") +".json"),'w') as fp:
			json.dump(custom_tweets, fp)
		with open(os.path.join("data",dataset,"shuffle"+str(shuffle),label+"_"+"items" + (("_"+str(j)) if j != -1 else "") +".json"),'w') as fp:
		 	json.dump(items_data, fp)


	@classmethod
	def extract_dataset(self,dataset): #dump the whold data : json extraction + features extraction + normalize + writing to a file
		print("dataset:  ",dataset)
		print("path: ",config.config["DATASET"][dataset])
		users = defaultdict(list)
		items = defaultdict(list)

		u = 0
		r = defaultdict(list)
		for path in glob.glob(os.path.join(config.config["DATASET"][dataset],"*.json")):
			#print("u: ",u)
			u += 1
			h = self.load_json(path,dataset)
			for key,array in h.items():
				users[key] += array

		for user_id,array in users.items():
			sorted_tweets = sorted(array, key=lambda k: k["tweet_age"])
			for i,tweet in enumerate(sorted_tweets):
		 		tweet["ratings_count"] = i + 1
		 		r[user_id].append(tweet)

		print(">>>> let's go handle users! :)")
		self.handle_users(r,dataset)
