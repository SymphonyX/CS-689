import db,extractor
from multipub import MultiPub
from ndcg import *
import helper, loader
#from stats import Stats

#Stats.check_count()

m = MultiPub()
m.binary_classification("LinearSVCWithAdditionalFeature")
#m.apply_classification_on_pairs()

# tweets, items = helper.load_dataset("imdb")
# x_train, y_train = loader.load_scikit_train("imdb", 1, 1, True, tweets, items)
# x_test, y_test = loader.load_scikit_test("imdb", 1, 1, True, tweets, items)

#m.binary_classification("LogisticRegressionSel", [2,4,7,8,9,10,11,12,13,15,16,17,18]) #feature selection to disable some features
#m.apply_regression("SGD_Regression_TMP")
#m.apply_regression("LassoRegression")
#m.apply_regression("Ridge_Regression")
#m.apply_regression_on_pairs()
#m.pooling_regression("PoolingRidgeRegression")



# pred_path = "/home/pooya/projects/MultiPub/data/mats/shuffle1/predictions/lasso-gridcv.1.imdb.preds"
# test_path = "/home/pooya/projects/MultiPub/data/imdb/shuffle1/features/test.dat"
# print(get_whole_ndcg(test_path, pred_path))


#extractor.Extractor.extract_dataset("goodreads")
#m.pooling_classification()
#extractor.Extractor.extract_dataset("imdb")
#db.DB().extract_data()
# for user in db.DB().users["imdb"].keys():
# 	for tweet in db.DB().users["imdb"][user]:
# 		print("")
# 		print(extractor.Extractor.extract_feature("imdb",tweet))
# 		print("")
