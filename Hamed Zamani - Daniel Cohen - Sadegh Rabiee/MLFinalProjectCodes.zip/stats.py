import sys
sys.path.append("../../")
import db,config,json
import os
import numpy as np
datasets = ["goodreads", "imdb", "pandora", "youtube"]

db = db.DB()
db.load_data()
for ds in datasets:
    print("dataset:  ", ds)
    al = 0
    pos = 0
    for user_id,arr in list(db.users[ds].items()):
        al += len(arr)
        for el in arr:
            if(el["engagement"] > 0):
                pos += 1
    print("% of pos:  ", float(pos) / al)



class Stats:
	@classmethod
	def check_eng(self):
		for dataset in db.DB().users.keys():
			eng = {}
			c = 0
			for user_id,array in db.DB().users[dataset].items():
				for item in array:
					c += 1
					if(item['engagement'] > 5):
						if("others" in eng.keys()):
							eng["others"] += 1
						else:
							eng["others"] = 1
					else:
						if(item['engagement'] in eng.keys()):
							eng[item['engagement']] += 1
						else:
							eng[item['engagement']] = 1
			arr = [x*100 / float(c) for x in eng.values()]
			print("")
			print("dataset: "+dataset)
			print(eng)
			print(arr)
			print("")
	@classmethod
	def check_count(self):
		for dataset in db.DB().users.keys():
			print("====")
			print("dataset: ",dataset)
			print("users: ",len(db.DB().users[dataset].items()))
			c = 0
			for user_id,array in db.DB().users[dataset].items():
				c += len(array)
			print("tweets: ",c)
			print("====")






	@classmethod
	def check_recsys(self):
		with open(config.config["DATASET"]["recsys"]) as json_data:
				data = json.load(json_data)
		eng = {}
		c = 0
		for user_id,hh in data.items():
			for h in h["films"]:
				c += 1
				if(h['engagement'] > 5):
					if("others" in eng.keys()):
						eng["others"] += 1
					else:
						eng["others"] = 1
				else:
					if(h['engagement'] in eng.keys()):
						eng[h['engagement']] += 1
					else:
						eng[h['engagement']] = 1
		arr = [x*100 / float(c) for x in eng.values()]
		print("")
		print(eng)
		print(arr)
		print("")
	# def draw_eng(self):
	# 	for dataset in db.DB().users.keys():
	# 		eng = {}
	# 		for user_id,array in db.DB().users[dataset].items():
	# 			for item in array:
	# 				if item['engagement'] in eng.keys():
	# 					eng[item['engagement']] += 1
	# 				else:
	# 					eng[item['engagement']] = 1

